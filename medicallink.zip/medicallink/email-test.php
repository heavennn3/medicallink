<?php
// Include your email configuration from main folder
require_once 'email-config.php';

echo "<h2>Testing Medical Link Email System</h2>";

// Test if PHPMailer loads
try {
    require_once 'PHPMailer/src/PHPMailer.php';
    require_once 'PHPMailer/src/SMTP.php';
    require_once 'PHPMailer/src/Exception.php';
    echo "✅ PHPMailer loaded successfully!<br>";
} catch (Exception $e) {
    echo "❌ PHPMailer failed to load: " . $e->getMessage() . "<br>";
    exit;
}

// Test email configuration
echo "Testing email configuration...<br>";

// Create a test appointment
$test_appointment = [
    'appoid' => '999',
    'appodate' => date('Y-m-d'),
    'pname' => 'Test Patient',
    'docname' => 'Dr. Smith',
    'title' => 'General Checkup',
    'scheduledate' => date('Y-m-d', strtotime('+7 days')),
    'scheduletime' => '14:30:00',
    'apponum' => 'T-001'
];

// Test the email function
$result = sendReceiptEmailEnhanced($test_appointment, 'fshmi977@gmail.com');

if ($result) {
    echo "✅ Email sent successfully! Check your Gmail inbox.<br>";
} else {
    echo "❌ Email failed to send. Check your error logs.<br>";
    echo "Make sure you've updated email-config.php with your Gmail credentials!<br>";
}

echo "<hr><h3>Next Steps:</h3>";
echo "1. Check your Gmail inbox for the test email<br>";
echo "2. If it fails, verify your Gmail app password in email-config.php<br>";
echo "3. Check WAMP error logs for detailed error messages";
?>