<?php
session_start();
if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
        header("location: ../login.php");
    }
} else {
    header("location: ../login.php");
}

include("../connection.php");
$id=$_GET["id"];


$sqlmain= "UPDATE doctor SET deleted=1 WHERE docid='$id'";
$result= $database->query($sqlmain);

header("location: doctors.php");
?>