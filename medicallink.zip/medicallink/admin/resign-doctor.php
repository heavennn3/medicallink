<?php
session_start();


if(!isset($_SESSION["user"]) || $_SESSION["usertype"] != 'a'){
    header("location: ../login.php");
    exit();
}

include("../connection.php");

if($_POST && isset($_POST['docid'])) {
    $docid = $database->real_escape_string($_POST['docid']);
    $resignation_reason = $database->real_escape_string($_POST['resignation_reason']);
    
    try {
        
        $doctor_query = $database->query("SELECT * FROM doctor WHERE docid='$docid'");
        if($doctor_query->num_rows == 0) {
            header("location: doctors.php?action=error&message=Doctor not found");
            exit();
        }
        
        $doctor_data = $doctor_query->fetch_assoc();
        
    
        $check_table = $database->query("SHOW TABLES LIKE 'resigneddoctor'");
        if($check_table->num_rows == 0) {
           
            $create_table = "CREATE TABLE resigneddoctor (
                docid INT PRIMARY KEY,
                docname VARCHAR(255) NOT NULL,
                docemail VARCHAR(255) UNIQUE NOT NULL,
                docnic VARCHAR(15) NOT NULL,
                doctel VARCHAR(15) NOT NULL,
                specialties INT NOT NULL,
                docpassword VARCHAR(255) NOT NULL,
                resignation_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                resignation_reason TEXT,
                original_created_date DATETIME
            )";
            
            if(!$database->query($create_table)) {
                header("location: doctors.php?action=error&message=Failed to create resigned doctors table");
                exit();
            }
        }
        
       
        $insert_query = "INSERT INTO resigneddoctor (
            docid, docname, docemail, docnic, doctel, specialties, 
            docpassword, resignation_reason, original_created_date
        ) VALUES (
            '{$doctor_data['docid']}',
            '{$doctor_data['docname']}',
            '{$doctor_data['docemail']}',
            '{$doctor_data['docnic']}',
            '{$doctor_data['doctel']}',
            '{$doctor_data['specialties']}',
            '{$doctor_data['docpassword']}',
            '$resignation_reason',
            NOW()
        )";
        
        if($database->query($insert_query)) {
     
            $database->query("DELETE FROM doctor WHERE docid='$docid'");
            
           
            $database->query("DELETE FROM webuser WHERE email='{$doctor_data['docemail']}'");
            
            header("location: doctors.php?action=resigned&message=Doctor resigned successfully and completely removed from system");
        } else {
            header("location: doctors.php?action=error&message=Failed to resign doctor: " . urlencode($database->error));
        }
    } catch (Exception $e) {
        header("location: doctors.php?action=error&message=" . urlencode($e->getMessage()));
    }
    exit();
} else {
    header("location: doctors.php");
    exit();
}
?>