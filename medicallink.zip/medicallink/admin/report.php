<?php
session_start();

if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
        header("location: ../login.php");
        exit();
    }
}else{
    header("location: ../login.php");
    exit();
}

include("../connection.php");


$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-d', strtotime('-30 days'));
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');
$report_type = isset($_GET['report_type']) ? $_GET['report_type'] : 'overview';


$totDoctors = $database->query("SELECT COUNT(*) AS cnt FROM doctor")->fetch_assoc()["cnt"];
$totPatients = $database->query("SELECT COUNT(*) AS cnt FROM patient")->fetch_assoc()["cnt"];
$totSchedules = $database->query("SELECT COUNT(*) AS cnt FROM schedule")->fetch_assoc()["cnt"];
$totAppointments = $database->query("SELECT COUNT(*) AS cnt FROM appointment")->fetch_assoc()["cnt"];


$last7 = array();
$labels7 = array();
$counts7 = array();

$stmt = $database->prepare("SELECT schedule.scheduledate AS dt, COUNT(appointment.appoid) AS cnt 
                           FROM appointment 
                           INNER JOIN schedule ON appointment.scheduleid=schedule.scheduleid 
                           WHERE schedule.scheduledate >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) 
                           GROUP BY schedule.scheduledate 
                           ORDER BY schedule.scheduledate ASC");
$stmt->execute();
$result = $stmt->get_result();


$map = array();
for ($i=6;$i>=0;$i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $map[$d] = 0;
}

if($result){
    while($r = $result->fetch_assoc()){
        $d = $r['dt'];
        if(isset($map[$d])) $map[$d] = intval($r['cnt']);
    }
}

foreach($map as $d=>$c){
    $labels7[] = date('M j', strtotime($d));
    $counts7[] = $c;
}


$labelsDoc = array();
$countsDoc = array();
$res = $database->query("SELECT doctor.docname AS name, COUNT(appointment.appoid) AS cnt 
                        FROM appointment 
                        INNER JOIN schedule ON appointment.scheduleid=schedule.scheduleid 
                        INNER JOIN doctor ON schedule.docid=doctor.docid 
                        GROUP BY doctor.docid 
                        ORDER BY cnt DESC 
                        LIMIT 10");
if($res){
    while($row = $res->fetch_assoc()){
        $labelsDoc[] = $row['name'];
        $countsDoc[] = intval($row['cnt']);
    }
}


$schedLabels = array();
$schedCounts = array();
$sr = $database->query("SELECT doctor.docname AS name, COUNT(schedule.scheduleid) AS cnt 
                       FROM schedule 
                       INNER JOIN doctor ON schedule.docid=doctor.docid 
                       GROUP BY doctor.docid 
                       ORDER BY cnt DESC 
                       LIMIT 10");
if($sr){
    while($r = $sr->fetch_assoc()){
        $schedLabels[] = $r['name'];
        $schedCounts[] = intval($r['cnt']);
    }
}


$monthlyLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
$monthlyCounts = array_fill(0, 12, 0);

$monthlyRes = $database->query("SELECT MONTH(schedule.scheduledate) as month, COUNT(appointment.appoid) as cnt 
                               FROM appointment 
                               INNER JOIN schedule ON appointment.scheduleid=schedule.scheduleid 
                               WHERE YEAR(schedule.scheduledate) = YEAR(CURDATE()) 
                               GROUP BY MONTH(schedule.scheduledate)");
if($monthlyRes){
    while($row = $monthlyRes->fetch_assoc()){
        $monthlyCounts[$row['month'] - 1] = intval($row['cnt']);
    }
}


$detailedAppointments = [];
$detailQuery = $database->prepare("SELECT a.appoid, a.apponum, p.pname, d.docname, s.title, s.scheduledate, s.scheduletime, a.appodate 
                                  FROM appointment a 
                                  INNER JOIN patient p ON a.pid = p.pid 
                                  INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
                                  INNER JOIN doctor d ON s.docid = d.docid 
                                  WHERE s.scheduledate BETWEEN ? AND ? 
                                  ORDER BY s.scheduledate DESC, s.scheduletime DESC");
$detailQuery->bind_param("ss", $date_from, $date_to);
$detailQuery->execute();
$detailResult = $detailQuery->get_result();

while($row = $detailResult->fetch_assoc()){
    $detailedAppointments[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Report - MedicalLink</title>
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .report-cards{display:flex;gap:16px;margin:20px 0;flex-wrap:wrap}
        .card{background:#fff;padding:18px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,0.06);flex:1;min-width:160px}
        .card h3{margin:0;font-size:18px;color:#666}
        .card p{font-size:28px;margin:8px 0 0;font-weight:600}
        .charts{display:flex;gap:20px;flex-wrap:wrap}
        .chart-card{flex:1;min-width:320px;background:#fff;padding:16px;border-radius:8px}
        canvas{max-width:100%;}
        .filter-container{background:#fff;padding:20px;border-radius:8px;margin:20px 0}
        .filter-form{display:flex;gap:15px;align-items:end;flex-wrap:wrap}
        .form-group{display:flex;flex-direction:column;gap:5px}
        .form-group label{font-weight:500;color:#555}
        .btn-print{margin-left:auto}
        .tab-container{margin:20px 0}
        .tab-buttons{display:flex;gap:0;border-bottom:1px solid #ddd}
        .tab-btn{padding:12px 24px;background:none;border:none;cursor:pointer;border-bottom:3px solid transparent}
        .tab-btn.active{background:#f8f9fa;border-bottom-color:#007bff;color:#007bff;font-weight:600}
        .tab-content{display:none;padding:20px 0}
        .tab-content.active{display:block}
    </style>
   
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <div class="dash-body">
            <h2 style="margin-top:20px">System Reports & Analytics</h2>
            
      
            <div class="filter-container">
                <form method="GET" class="filter-form">
                    <div class="form-group">
                        <label for="report_type">Report Type</label>
                        <select name="report_type" id="report_type" class="input-text" onchange="this.form.submit()">
                            <option value="overview" <?= $report_type == 'overview' ? 'selected' : '' ?>>Overview Dashboard</option>
                            <option value="detailed" <?= $report_type == 'detailed' ? 'selected' : '' ?>>Detailed Appointments</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="date_from">From Date</label>
                        <input type="date" name="date_from" id="date_from" class="input-text" value="<?= $date_from ?>">
                    </div>
                    <div class="form-group">
                        <label for="date_to">To Date</label>
                        <input type="date" name="date_to" id="date_to" class="input-text" value="<?= $date_to ?>">
                    </div>
                    <button type="submit" class="login-btn btn-primary btn">Apply Filters</button>
                    <button type="button" class="login-btn btn-primary-soft btn btn-print" onclick="window.print()">Print Report</button>
                </form>
            </div>

            <?php if($report_type == 'overview'): ?>
            
  
            <div class="report-cards">
                <div class="card">
                    <h3>Total Doctors</h3>
                    <p><?php echo intval($totDoctors); ?></p>
                </div>
                <div class="card">
                    <h3>Total Patients</h3>
                    <p><?php echo intval($totPatients); ?></p>
                </div>
                <div class="card">
                    <h3>Total Sessions</h3>
                    <p><?php echo intval($totSchedules); ?></p>
                </div>
                <div class="card">
                    <h3>Total Appointments</h3>
                    <p><?php echo intval($totAppointments); ?></p>
                </div>
            </div>

            <div class="charts">
                <div class="chart-card">
                    <h3>Appointments - Last 7 Days</h3>
                    <canvas id="line7"></canvas>
                </div>

                <div class="chart-card">
                    <h3>Top Doctors by Appointments</h3>
                    <canvas id="barDoc"></canvas>
                </div>

                <div class="chart-card">
                    <h3>Monthly Appointments (<?= date('Y') ?>)</h3>
                    <canvas id="monthlyChart"></canvas>
                </div>

                <div class="chart-card">
                    <h3>Sessions per Doctor</h3>
                    <canvas id="sessionsChart"></canvas>
                </div>
            </div>

            <div style="margin-top:20px;">
                <h3>Recent Activity Summary</h3>
                <table class="sub-table" style="width:100%;border-collapse:collapse">
                    <thead>
                        <tr>
                            <th class="table-headin">Date</th>
                            <th class="table-headin">Appointments</th>
                            <th class="table-headin">Day of Week</th>
                            <th class="table-headin">Trend</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $prevCount = null;
                        foreach($map as $d=>$c){ 
                            $trend = '';
                            if($prevCount !== null) {
                                if($c > $prevCount) $trend = '📈 Increase';
                                elseif($c < $prevCount) $trend = '📉 Decrease';
                                else $trend = '➡️ Stable';
                            }
                            $prevCount = $c;
                            echo "<tr>
                                <td>".htmlspecialchars($d)."</td>
                                <td style='text-align:center'>".intval($c)."</td>
                                <td style='text-align:center'>".date('l', strtotime($d))."</td>
                                <td style='text-align:center'>".$trend."</td>
                            </tr>"; 
                        } 
                        ?>
                    </tbody>
                </table>
            </div>

            <?php else: ?>

      
            <div style="margin-top:20px;">
                <h3>Detailed Appointment Report (<?= $date_from ?> to <?= $date_to ?>)</h3>
                <p>Showing <?= count($detailedAppointments) ?> appointments</p>
                
                <table class="sub-table" style="width:100%;border-collapse:collapse">
                    <thead>
                        <tr>
                            <th class="table-headin">Appointment ID</th>
                            <th class="table-headin">Appointment #</th>
                            <th class="table-headin">Patient Name</th>
                            <th class="table-headin">Doctor</th>
                            <th class="table-headin">Session</th>
                            <th class="table-headin">Schedule Date</th>
                            <th class="table-headin">Schedule Time</th>
                            <th class="table-headin">Booked Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($detailedAppointments)): ?>
                            <tr>
                                <td colspan="8" style="text-align:center;padding:20px;">
                                    No appointments found for the selected date range.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($detailedAppointments as $appointment): ?>
                            <tr>
                                <td><?= htmlspecialchars($appointment['appoid']) ?></td>
                                <td style="text-align:center"><?= htmlspecialchars($appointment['apponum']) ?></td>
                                <td><?= htmlspecialchars($appointment['pname']) ?></td>
                                <td><?= htmlspecialchars($appointment['docname']) ?></td>
                                <td><?= htmlspecialchars($appointment['title']) ?></td>
                                <td><?= htmlspecialchars($appointment['scheduledate']) ?></td>
                                <td><?= htmlspecialchars($appointment['scheduletime']) ?></td>
                                <td><?= htmlspecialchars($appointment['appodate']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php endif; ?>
        </div>
    </div>

    <script>
       
        const labels7 = <?php echo json_encode($labels7); ?>;
        const counts7 = <?php echo json_encode($counts7); ?>;

        const ctx7 = document.getElementById('line7').getContext('2d');
        new Chart(ctx7, {
            type: 'line',
            data: {
                labels: labels7,
                datasets: [{
                    label: 'Appointments',
                    data: counts7,
                    borderColor: 'rgba(10,118,216,0.9)',
                    backgroundColor: 'rgba(10,118,216,0.15)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                scales: { y: { beginAtZero: true, precision:0 } }
            }
        });

      
        const labelsDoc = <?php echo json_encode($labelsDoc); ?>;
        const countsDoc = <?php echo json_encode($countsDoc); ?>;

        const ctxDoc = document.getElementById('barDoc').getContext('2d');
        new Chart(ctxDoc, {
            type: 'bar',
            data: {
                labels: labelsDoc,
                datasets: [{
                    label: 'Appointments',
                    data: countsDoc,
                    backgroundColor: 'rgba(57,108,240,0.8)'
                }]
            },
            options: { 
                responsive: true, 
                scales: { y: { beginAtZero: true, precision:0 } },
                indexAxis: 'y'
            }
        });

       
        const monthlyLabels = <?php echo json_encode($monthlyLabels); ?>;
        const monthlyCounts = <?php echo json_encode($monthlyCounts); ?>;

        const ctxMonthly = document.getElementById('monthlyChart').getContext('2d');
        new Chart(ctxMonthly, {
            type: 'bar',
            data: {
                labels: monthlyLabels,
                datasets: [{
                    label: 'Appointments',
                    data: monthlyCounts,
                    backgroundColor: 'rgba(40,167,69,0.8)'
                }]
            },
            options: { 
                responsive: true, 
                scales: { y: { beginAtZero: true, precision:0 } }
            }
        });

     
        const schedLabels = <?php echo json_encode($schedLabels); ?>;
        const schedCounts = <?php echo json_encode($schedCounts); ?>;

        const ctxSessions = document.getElementById('sessionsChart').getContext('2d');
        new Chart(ctxSessions, {
            type: 'doughnut',
            data: {
                labels: schedLabels,
                datasets: [{
                    data: schedCounts,
                    backgroundColor: [
                        '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', 
                        '#9966FF', '#FF9F40', '#8AC926', '#1982C4',
                        '#6A4C93', '#FF595E'
                    ]
                }]
            },
            options: { 
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });


        function openTab(tabName) {
            const tabContents = document.getElementsByClassName('tab-content');
            const tabButtons = document.getElementsByClassName('tab-btn');
            
            for (let i = 0; i < tabContents.length; i++) {
                tabContents[i].classList.remove('active');
            }
            
            for (let i = 0; i < tabButtons.length; i++) {
                tabButtons[i].classList.remove('active');
            }
            
            document.getElementById(tabName).classList.add('active');
            event.currentTarget.classList.add('active');
        }
    </script>

</body>
</html>