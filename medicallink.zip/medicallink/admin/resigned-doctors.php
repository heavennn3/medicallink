<?php
session_start();
if(!isset($_SESSION["user"]) || $_SESSION["usertype"] != 'a'){
    header("location: ../login.php");
    exit();
}

include("../connection.php");


$check_table = $database->query("SHOW TABLES LIKE 'resigneddoctor'");
if($check_table->num_rows == 0) {
    
    $table_exists = false;
    $result = null;
} else {
    $table_exists = true;
  
    $sqlmain = "SELECT rd.*, s.sname as specialty_name 
                FROM resigneddoctor rd 
                LEFT JOIN specialties s ON rd.specialties = s.id 
                ORDER BY rd.resignation_date DESC";
    $result = $database->query($sqlmain);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <title>Resigned Doctors</title>
</head>
<body>
    <div class="container">
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title">Administrator</p>
                                    <p class="profile-subtitle">admin@medicallink.com</p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-dashbord" >
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></a></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-doctor">
                        <a href="doctors.php" class="non-style-link-menu"><div><p class="menu-text">Doctors</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-schedule">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">Schedule</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">Appointment</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-patient">
                        <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">Patients</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn">
                        <a href="report.php" class="non-style-link-menu"><div><p class="menu-text">Reports</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-active menu-icon-doctor-active">
                        <a href="resigned-doctors.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Resigned Doctors</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn">
                        <a href="deleted-doctors.php" class="non-style-link-menu"><div><p class="menu-text">Deleted Doctors</p></div></a>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="dash-body">
            <table border="0" width="100%" style="border-spacing: 0; margin:0; padding:0; margin-top:25px;">
                <tr>
                    <td width="13%">
                        <a href="doctors.php"><button class="login-btn btn-primary-soft btn btn-icon-back">Back to Doctors</button></a>
                    </td>
                    <td>
                        <p style="font-size: 23px; padding-left:12px; font-weight: 600;">Resigned Doctors</p>
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 
                            date_default_timezone_set('Asia/Kuala_Lumpur');
                            $today = date('Y-m-d');
                            echo $today;
                            ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button class="btn-label" style="display: flex;justify-content: center;align-items: center;">
                            <img src="../img/calendar.svg" width="100%">
                        </button>
                    </td>
                </tr>
                <tr>
                    <td colspan="4" style="padding-top:10px;">
                        <p class="heading-main12" style="margin-left: 45px;font-size:18px;color:rgb(49, 49, 49)">
                            Resigned Doctors (<?php echo ($table_exists && $result && $result->num_rows) ? $result->num_rows : 0; ?>)
                        </p>
                    </td>
                </tr>
            </table>
            
            <center>
                <div class="abc scroll">
                    <table width="93%" class="sub-table scrolldown" border="0">
                        <thead>
                            <tr>
                                <th class="table-headin">Doctor Name</th>
                                <th class="table-headin">Email</th>
                                <th class="table-headin">Specialty</th>
                                <th class="table-headin">Resignation Date</th>
                                <th class="table-headin">Resignation Reason</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if(!$table_exists) {
                                echo '<tr>
                                    <td colspan="5">
                                    <br><br><br><br>
                                    <center>
                                    <img src="../img/notfound.svg" width="25%">
                                    <br>
                                    <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">No Resigned Doctors Yet</p>
                                    <p style="color: #666; margin-top: 10px;">The resigned doctors table will be created when the first doctor resigns.</p>
                                    </center>
                                    <br><br><br><br>
                                    </td>
                                    </tr>';
                            } elseif ($result->num_rows == 0) {
                                echo '<tr>
                                    <td colspan="5">
                                    <br><br><br><br>
                                    <center>
                                    <img src="../img/notfound.svg" width="25%">
                                    <br>
                                    <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">No resigned doctors found.</p>
                                    </center>
                                    <br><br><br><br>
                                    </td>
                                    </tr>';
                            } else {
                                while($row = $result->fetch_assoc()){
                                    echo '<tr>
                                        <td>'.htmlspecialchars($row["docname"]).'</td>
                                        <td>'.htmlspecialchars($row["docemail"]).'</td>
                                        <td>'.htmlspecialchars($row["specialty_name"]).'</td>
                                        <td>'.date('Y-m-d H:i', strtotime($row["resignation_date"])).'</td>
                                        <td>'.($row["resignation_reason"] ? htmlspecialchars($row["resignation_reason"]) : 'Not specified').'</td>
                                    </tr>';
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </center>
        </div>
    </div>
</body>
</html>