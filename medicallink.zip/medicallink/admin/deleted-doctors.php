<?php
session_start();
if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
        header("location: ../login.php");
    }
} else {
    header("location: ../login.php");
}

include("../connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <title>Deleted Doctors</title>
</head>
<body>
    <div class="container">
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title">Administrator</p>
                                    <p class="profile-subtitle">admin@medicallink.com</p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                    </table>
                    </td>
                
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-dashbord" >
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></a></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-doctor">
                        <a href="doctors.php" class="non-style-link-menu"><div><p class="menu-text">Doctors</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-schedule">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">Schedule</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">Appointment</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-patient">
                        <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">Patients</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn">
                        <a href="report.php" class="non-style-link-menu"><div><p class="menu-text">Reports</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-active">
                        <a href="deleted-doctors.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Deleted Doctors</p></div></a>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="dash-body">
            <table border="0" width="100%" style="border-spacing: 0;margin:0;padding:0;margin-top:25px;">
                <tr>
                    <td width="13%">
                        <a href="doctors.php"><button class="login-btn btn-primary-soft btn btn-icon-back">Back to Doctors</button></a>
                    </td>
                    <td>
                        <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">Deleted Doctors</p>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="4" style="padding-top:10px;">
                        <center>
                        <div class="abc scroll">
                        <table width="93%" class="sub-table scrolldown" border="0">
                        <thead>
                        <tr>
                            <th class="table-headin">Doctor Name</th>
                            <th class="table-headin">Email</th>
                            <th class="table-headin">Specialties</th>
                            <th class="table-headin">Events</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $sqlmain= "select * from doctor where deleted=1 order by docid desc";
                            $result= $database->query($sqlmain);

                            if($result->num_rows==0){
                                echo '<tr>
                                <td colspan="4">
                                <center>
                                <img src="../img/notfound.svg" width="25%">
                                <br>
                                <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">No deleted doctors found!</p>
                                </center>
                                </td>
                                </tr>';
                            } else {
                                for ($x=0; $x<$result->num_rows;$x++){
                                    $row=$result->fetch_assoc();
                                    $docid=$row["docid"];
                                    $name=$row["docname"];
                                    $email=$row["docemail"];
                                    $spe=$row["specialties"];
                                    $spcil_res= $database->query("select sname from specialties where id='$spe'");
                                    $spcil_array= $spcil_res->fetch_assoc();
                                    $spcil_name=$spcil_array["sname"];
                                    echo '<tr>
                                        <td>'.substr($name,0,30).'</td>
                                        <td>'.substr($email,0,20).'</td>
                                        <td>'.substr($spcil_name,0,20).'</td>
                                        <td>
                                        <div style="display:flex;justify-content: center;">
                                        <a href="restore-doctor.php?id='.$docid.'" class="non-style-link"><button class="btn-primary-soft btn button-icon btn-edit">Restore</button></a>
                                        &nbsp;&nbsp;&nbsp;
                                        <a href="?action=permanent_delete&id='.$docid.'&name='.$name.'" class="non-style-link"><button class="btn-primary-soft btn button-icon btn-delete">Permanently Delete</button></a>
                                        </div>
                                        </td>
                                    </tr>';
                                }
                            }
                        ?>
                        </tbody>
                        </table>
                        </div>
                        </center>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <?php 
    if($_GET){
        $id=$_GET["id"];
        $action=$_GET["action"];
        if($action=='permanent_delete'){
            $nameget=$_GET["name"];
            echo '
            <div id="popup1" class="overlay">
                    <div class="popup">
                    <center>
                        <h2>Permanently Delete?</h2>
                        <a class="close" href="deleted-doctors.php">&times;</a>
                        <div class="content">
                            You are about to permanently delete this doctor record<br>('.substr($nameget,0,40).').<br><br>
                            <strong style="color:red;">Warning: This action cannot be undone!</strong>
                        </div>
                        <div style="display: flex;justify-content: center;">
                        <a href="permanent-delete-doctor.php?id='.$id.'" class="non-style-link"><button class="btn-primary btn" style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;background-color:red;">Yes, Delete Permanently</button></a>&nbsp;&nbsp;&nbsp;
                        <a href="deleted-doctors.php" class="non-style-link"><button class="btn-primary btn" style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;">Cancel</button></a>
                        </div>
                    </center>
            </div>
            </div>
            ';
        }
    }
    ?>
</body>
</html>