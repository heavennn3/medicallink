<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../css/popup.css">
        
    <title>Doctor</title>
</head>
<body>
    <?php

    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            header("location: ../login.php");
        }

    }else{
        header("location: ../login.php");
    }

    include("../connection.php");

    if($_POST){

        $result= $database->query("select * from webuser");
        $name=$_POST['name'];
        $nic=$_POST['nic'];
        $spec=$_POST['spec'];
        $email=$_POST['email'];
        $tele=$_POST['Tele'];
        $password=$_POST['password'];
        $cpassword=$_POST['cpassword'];
        
 
        if (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
            $error = '8'; 
            header("location: doctors.php?action=add&error=".$error);
            exit();
        }

        if (!preg_match('/^[0-9]+$/', $nic)) {
            $error = '5'; 
            header("location: doctors.php?action=add&error=".$error);
            exit();
        }
        

        if (!preg_match('/^[0-9]+$/', $tele)) {
            $error = '6'; 
            header("location: doctors.php?action=add&error=".$error);
            exit();
        }

        if ($password==$cpassword){
            $error='3';
            $result= $database->query("select * from webuser where email='$email';");
            if($result->num_rows==1){
                $error='1';
            }else{

    
                $sql1="insert into doctor(docemail, docname, docpassword, docnic, doctel, specialties) values('$email','$name','$password','$nic','$tele','$spec')";
                
                
                $sql2="insert into webuser(email, usertype) values('$email','d')";
                
      
                
                if($database->query($sql1) && $database->query($sql2)){
                    $error= '4';
                } else {
                    $error = '7'; 
                }
                
            }
            
        }else{
            $error='2';
        }
        
    }else{
        $error='3';
    }

    header("location: doctors.php?action=add&error=".$error);
    ?>

</body>
</html>