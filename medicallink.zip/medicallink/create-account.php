<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/signup.css">
    <title>Create Account</title>
    <style>
        .container{
            animation: transitionIn-X 0.5s;
        }
        .error-message {
            color: #ff0000;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }
        .input-error {
            border: 1px solid #ff0000 !important;
        }
    </style>
</head>
<body>
<?php

session_start();

$_SESSION["user"] = "";
$_SESSION["usertype"] = "";
date_default_timezone_set('Asia/Kuala_Lumpur');
$_SESSION["date"] = date('Y-m-d');

include("connection.php");
$error = '';

if($_POST){
    $fname = $_SESSION['personal']['fname'];
    $lname = $_SESSION['personal']['lname'];
    $name = $fname . " " . $lname;
    $address = $_SESSION['personal']['address'];
    $nic = $_SESSION['personal']['nic'];
    $dob = $_SESSION['personal']['dob'];
    $email = $_POST['newemail'];
    $tele = $_POST['tele'];
    $newpassword = $_POST['newpassword'];
    $cpassword = $_POST['cpassword'];
    
    // Server-side validation for phone number
    if (!empty($tele) && !preg_match("/^[0-9]+$/", $tele)) {
        $error = '<label class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Phone number should contain only numbers.</label>';
    } else if ($newpassword == $cpassword){
        // Check if email exists
        $stmt = $database->prepare("SELECT email FROM webuser WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if($result->num_rows == 1){
            $error = '<label class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Email already registered.</label>';
        } else {
            // Insert new patient
            $stmt = $database->prepare("INSERT INTO patient(pemail, pname, ppassword, paddress, pnic, pdob, ptel) VALUES(?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssss", $email, $name, $newpassword, $address, $nic, $dob, $tele);
            $stmt->execute();
            
            // Insert webuser
            $stmt = $database->prepare("INSERT INTO webuser(email, usertype) VALUES(?, 'p')");
            $stmt->bind_param("s", $email);
            $stmt->execute();

            $_SESSION["user"] = $email;
            $_SESSION["usertype"] = "p";
            $_SESSION["username"] = $fname;

            header('Location: patient/index.php');
            exit();
        }
    } else {
        $error = '<label class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Passwords do not match.</label>';
    }
}
?>

    <center>
    <div class="container">
        <table border="0" style="width: 69%;">
            <tr>
                <td colspan="2">
                    <p class="header-text">Let's Get Started</p>
                    <p class="sub-text">It's Okey, Now Create User Account.</p>
                </td>
            </tr>
            <tr>
                <form action="" method="POST" onsubmit="return validateForm()">
                <td class="label-td" colspan="2">
                    <label for="newemail" class="form-label">Email: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="email" name="newemail" class="input-text" placeholder="Email Address" required
                           value="<?php echo isset($_POST['newemail']) ? htmlspecialchars($_POST['newemail']) : ''; ?>">
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="tele" class="form-label">Mobile Number: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="text" name="tele" class="input-text" placeholder="ex: 0123456789" 
                           oninput="validatePhone(this)"
                           value="<?php echo isset($_POST['tele']) ? htmlspecialchars($_POST['tele']) : ''; ?>">
                    <div class="error-message" id="tele-error">Only numbers allowed (0-9)</div>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="newpassword" class="form-label">Create New Password: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="password" name="newpassword" class="input-text" placeholder="New Password" required>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="cpassword" class="form-label">Confirm Password: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="password" name="cpassword" class="input-text" placeholder="Confirm Password" required>
                </td>
            </tr>
     
            <tr>
                <td colspan="2">
                    <?php echo $error ?>
                </td>
            </tr>
            
            <tr>
                <td>
                    <input type="reset" value="Reset" class="login-btn btn-primary-soft btn" onclick="clearErrors()">
                </td>
                <td>
                    <input type="submit" value="Sign Up" class="login-btn btn-primary btn">
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">Already have an account&#63; </label>
                    <a href="login.php" class="hover-link1 non-style-link">Login</a>
                    <br><br><br>
                </td>
            </tr>
            </form>
        </table>
    </div>
</center>

<script>
// Function to validate phone number (numbers only)
function validatePhone(input) {
    const phoneRegex = /^[0-9]*$/;
    const errorElement = document.getElementById('tele-error');
    
    // Remove any non-numeric characters
    input.value = input.value.replace(/[^0-9]/g, '');
    
    if (input.value !== '' && !phoneRegex.test(input.value)) {
        input.classList.add('input-error');
        errorElement.style.display = 'block';
        return false;
    } else {
        input.classList.remove('input-error');
        errorElement.style.display = 'none';
        return true;
    }
}

// Function to clear all errors when reset button is clicked
function clearErrors() {
    const errorMessages = document.querySelectorAll('.error-message');
    const errorInputs = document.querySelectorAll('.input-error');
    
    errorMessages.forEach(error => {
        error.style.display = 'none';
    });
    
    errorInputs.forEach(input => {
        input.classList.remove('input-error');
    });
}

// Function to validate entire form before submission
function validateForm() {
    const phoneInput = document.getElementsByName('tele')[0];
    
    // Phone validation is optional, but if provided, must be numbers only
    if (phoneInput.value !== '') {
        return validatePhone(phoneInput);
    }
    
    return true;
}

// Real-time validation as user types
document.addEventListener('DOMContentLoaded', function() {
    const phoneInput = document.getElementsByName('tele')[0];
    
    // Prevent non-numeric characters in phone field
    phoneInput.addEventListener('input', function(e) {
        this.value = this.value.replace(/[^0-9]/g, '');
    });
    
    // Add max length for Malaysian phone numbers (typically 10-11 digits)
    phoneInput.setAttribute('maxlength', '11');
});
</script>
</body>
</html>