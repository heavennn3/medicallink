<?php
// debug-receipt.php
session_start();
require_once 'email-config.php';

echo "<h2>Debugging Receipt Sending</h2>";

// Check if form was submitted
if ($_POST) {
    echo "<h3>Form Data Received:</h3>";
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
    
    // Simulate the receipt sending
    if (isset($_POST['email']) && isset($_POST['appointment_id'])) {
        $email = $_POST['email'];
        $appointment_id = $_POST['appointment_id'];
        
        echo "Attempting to send to: $email<br>";
        echo "Appointment ID: $appointment_id<br>";
        
        // You would fetch the appointment data from database here
        $appointment = [
            'appoid' => $appointment_id,
            'appodate' => date('Y-m-d'),
            'pname' => 'Test Patient',
            'docname' => 'Test Doctor',
            'title' => 'Test Session',
            'scheduledate' => date('Y-m-d'),
            'scheduletime' => '14:30:00',
            'apponum' => '1'
        ];
        
        $result = sendReceiptEmailEnhanced($appointment, $email);
        
        if ($result) {
            echo "✅ Email sent successfully!";
        } else {
            echo "❌ Email failed to send.";
        }
    }
} else {
    echo "No form data received. Check your form submission.";
}
?>