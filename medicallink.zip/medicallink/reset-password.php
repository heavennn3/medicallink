<?php
// reset-password.php
session_start();
include("connection.php");

$message = '';
$success = false;

if(isset($_POST['reset_password'])) {
    $token = $_POST['token'];
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if($new_password === $confirm_password) {
        // Verify token and expiry
        $result = $database->query("SELECT * FROM webuser WHERE email='$email' AND reset_token='$token' AND reset_expiry > NOW()");
        
        if($result->num_rows == 1) {
            // Update password based on user type
            $utype = $result->fetch_assoc()['usertype'];
            
            if($utype == 'p') {
                $database->query("UPDATE patient SET ppassword='$new_password' WHERE pemail='$email'");
            } elseif($utype == 'a') {
                $database->query("UPDATE admin SET apassword='$new_password' WHERE aemail='$email'");
            } elseif($utype == 'd') {
                $database->query("UPDATE doctor SET docpassword='$new_password' WHERE docemail='$email'");
            }
            
            // Clear reset token
            $database->query("UPDATE webuser SET reset_token=NULL, reset_expiry=NULL WHERE email='$email'");
            
            $message = '<label style="color:green;">Password reset successfully! <a href="login.php">Login here</a></label>';
            $success = true;
        } else {
            $message = '<label style="color:rgb(255, 62, 62);">Invalid or expired reset token.</label>';
        }
    } else {
        $message = '<label style="color:rgb(255, 62, 62);">Passwords do not match.</label>';
    }
} elseif(isset($_GET['token']) && isset($_GET['email'])) {
    $token = $_GET['token'];
    $email = $_GET['email'];
    
    // Verify token is valid and not expired
    $result = $database->query("SELECT * FROM webuser WHERE email='$email' AND reset_token='$token' AND reset_expiry > NOW()");
    
    if($result->num_rows == 0) {
        $message = '<label style="color:rgb(255, 62, 62);">Invalid or expired reset link.</label>';
    }
} else {
    header('location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/login.css">
    <title>Reset Password</title>
</head>
<body>
    <center>
    <div class="container">
        <table border="0" style="margin: 0;padding: 0;width: 60%;">
            <tr>
                <td>
                    <p class="header-text">Reset Your Password</p>
                </td>
            </tr>
            
            <?php if(!$success && $message == ''): ?>
            <tr>
                <td>
                    <p class="sub-text">Enter your new password</p>
                </td>
            </tr>
            
            <form action="" method="POST">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token'] ?? $_POST['token']); ?>">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email'] ?? $_POST['email']); ?>">
            
            <tr>
                <td class="label-td">
                    <label for="new_password" class="form-label">New Password: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <input type="password" name="new_password" class="input-text" placeholder="New Password" required>
                </td>
            </tr>
            
            <tr>
                <td class="label-td">
                    <label for="confirm_password" class="form-label">Confirm Password: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <input type="password" name="confirm_password" class="input-text" placeholder="Confirm Password" required>
                </td>
            </tr>
            
            <tr>
                <td><br>
                <?php echo $message; ?>
                </td>
            </tr>
            
            <tr>
                <td>
                    <input type="submit" name="reset_password" value="Reset Password" class="login-btn btn-primary btn">
                </td>
            </tr>
            </form>
            
            <?php else: ?>
            <tr>
                <td>
                    <br>
                    <?php echo $message; ?>
                    <br><br>
                    <a href="login.php" class="non-style-link"><button class="login-btn btn-primary btn">Back to Login</button></a>
                </td>
            </tr>
            <?php endif; ?>
        </table>
    </div>
    </center>
</body>
</html>