<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/signup.css">
    <title>Sign Up</title>
    <style>
        .error-message {
            color: #ff0000;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }
        .input-error {
            border: 1px solid #ff0000 !important;
        }
    </style>
</head>
<body>
<?php
session_start();

$_SESSION["user"]="";
$_SESSION["usertype"]="";

date_default_timezone_set('Asia/Kuala_Lumpur');
$date = date('Y-m-d');

$_SESSION["date"]=$date;

if($_POST){
    // Validate inputs server-side as well
    $errors = [];
    
    // Name validation (alphabets and spaces only)
    if (!preg_match("/^[a-zA-Z ]+$/", $_POST['fname'])) {
        $errors[] = "First name should contain only letters and spaces";
    }
    if (!preg_match("/^[a-zA-Z ]+$/", $_POST['lname'])) {
        $errors[] = "Last name should contain only letters and spaces";
    }
    
    // NIC validation (numbers only)
    if (!preg_match("/^[0-9]+$/", $_POST['nic'])) {
        $errors[] = "NIC should contain only numbers";
    }
    
    // If no errors, proceed
    if (empty($errors)) {
        $_SESSION["personal"]=array(
            'fname'=>$_POST['fname'],
            'lname'=>$_POST['lname'],
            'address'=>$_POST['address'],
            'nic'=>$_POST['nic'],
            'dob'=>$_POST['dob']
        );
        header("location: create-account.php");
        exit();
    } else {
        // Store errors in session to display them
        $_SESSION['form_errors'] = $errors;
    }
}
?>

    <center>
    <div class="container">
        <table border="0">
            <tr>
                <td colspan="2">
                    <p class="header-text">Let's Get Started</p>
                    <p class="sub-text">Add Your Personal Details to Continue</p>
                    
                    <!-- Display errors if any -->
                    <?php 
                    if (isset($_SESSION['form_errors'])) {
                        foreach ($_SESSION['form_errors'] as $error) {
                            echo '<p style="color: red; font-size: 14px;">' . $error . '</p>';
                        }
                        unset($_SESSION['form_errors']);
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <form action="" method="POST" onsubmit="return validateForm()">
                <td class="label-td" colspan="2">
                    <label for="name" class="form-label">Name: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <input type="text" name="fname" class="input-text" placeholder="First Name" required 
                           oninput="validateName(this)" 
                           value="<?php echo isset($_POST['fname']) ? htmlspecialchars($_POST['fname']) : ''; ?>">
                    <div class="error-message" id="fname-error">Only letters and spaces allowed</div>
                </td>
                <td class="label-td">
                    <input type="text" name="lname" class="input-text" placeholder="Last Name" required 
                           oninput="validateName(this)"
                           value="<?php echo isset($_POST['lname']) ? htmlspecialchars($_POST['lname']) : ''; ?>">
                    <div class="error-message" id="lname-error">Only letters and spaces allowed</div>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="address" class="form-label">Address: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="text" name="address" class="input-text" placeholder="Address" required
                           value="<?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?>">
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="nic" class="form-label">NIC: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="text" name="nic" class="input-text" placeholder="NIC Number" required 
                           oninput="validateNIC(this)" maxlength="12"
                           value="<?php echo isset($_POST['nic']) ? htmlspecialchars($_POST['nic']) : ''; ?>">
                    <div class="error-message" id="nic-error">Only numbers allowed</div>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="dob" class="form-label">Date of Birth: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="date" name="dob" class="input-text" required
                           value="<?php echo isset($_POST['dob']) ? htmlspecialchars($_POST['dob']) : ''; ?>">
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                </td>
            </tr>

            <tr>
                <td>
                    <input type="reset" value="Reset" class="login-btn btn-primary-soft btn" onclick="clearErrors()">
                </td>
                <td>
                    <input type="submit" value="Next" class="login-btn btn-primary btn">
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">Already have an account&#63; </label>
                    <a href="login.php" class="hover-link1 non-style-link">Login</a>
                    <br><br><br>
                </td>
            </tr>
            </form>
        </table>
    </div>
</center>

<script>
// Function to validate name fields (alphabets and spaces only)
function validateName(input) {
    const nameRegex = /^[a-zA-Z\s]*$/;
    const errorElement = document.getElementById(input.name + '-error');
    
    if (!nameRegex.test(input.value)) {
        input.classList.add('input-error');
        errorElement.style.display = 'block';
        return false;
    } else {
        input.classList.remove('input-error');
        errorElement.style.display = 'none';
        return true;
    }
}

// Function to validate NIC (numbers only)
function validateNIC(input) {
    const nicRegex = /^[0-9]*$/;
    const errorElement = document.getElementById('nic-error');
    
    if (!nicRegex.test(input.value)) {
        input.classList.add('input-error');
        errorElement.style.display = 'block';
        return false;
    } else {
        input.classList.remove('input-error');
        errorElement.style.display = 'none';
        return true;
    }
}

// Function to clear all errors when reset button is clicked
function clearErrors() {
    const errorMessages = document.querySelectorAll('.error-message');
    const errorInputs = document.querySelectorAll('.input-error');
    
    errorMessages.forEach(error => {
        error.style.display = 'none';
    });
    
    errorInputs.forEach(input => {
        input.classList.remove('input-error');
    });
}

// Function to validate entire form before submission
function validateForm() {
    const fname = document.getElementsByName('fname')[0];
    const lname = document.getElementsByName('lname')[0];
    const nic = document.getElementsByName('nic')[0];
    
    const isFnameValid = validateName(fname);
    const isLnameValid = validateName(lname);
    const isNicValid = validateNIC(nic);
    
    return isFnameValid && isLnameValid && isNicValid;
}

// Real-time validation as user types
document.addEventListener('DOMContentLoaded', function() {
    const fnameInput = document.getElementsByName('fname')[0];
    const lnameInput = document.getElementsByName('lname')[0];
    const nicInput = document.getElementsByName('nic')[0];
    
    // Prevent non-alphabet characters in name fields
    fnameInput.addEventListener('input', function(e) {
        this.value = this.value.replace(/[^a-zA-Z\s]/g, '');
    });
    
    lnameInput.addEventListener('input', function(e) {
        this.value = this.value.replace(/[^a-zA-Z\s]/g, '');
    });
    
    // Prevent non-numeric characters in NIC field
    nicInput.addEventListener('input', function(e) {
        this.value = this.value.replace(/[^0-9]/g, '');
    });
});
</script>
</body>
</html>