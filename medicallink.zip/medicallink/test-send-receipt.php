<?php
require_once 'email-config.php';

echo "<h2>Testing Receipt Email Sending</h2>";

// Test appointment data matching your form
$test_appointment = [
    'appoid' => '20',
    'appodate' => '2025-11-20',
    'pname' => 'imran fahmi',
    'docname' => 'Dr. Doctor Fahmi',
    'title' => 'test email',
    'scheduledate' => '2025-11-20',
    'scheduletime' => '12:12:00',
    'apponum' => '1'
];

$to_email = 'ifahmi972@gmail.com';

echo "Sending email to: $to_email<br>";

// Test the email function
$result = sendReceiptEmailEnhanced($test_appointment, $to_email);

if ($result) {
    echo "✅ Email sent successfully to $to_email!<br>";
    echo "Check your inbox and spam folder.<br>";
} else {
    echo "❌ Email failed to send.<br>";
    echo "Check your WAMP error logs for details.<br>";
}

echo "<hr><h3>Appointment Details:</h3>";
echo "<pre>";
print_r($test_appointment);
echo "</pre>";
?>