<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "medicallink";
$port = 3306;

$database = new mysqli($servername, $username, $password, $dbname, $port);

if ($database->connect_error) {
    die("connection failed dickhead :p" . $database->connect_error);
}
?>
