<?php
session_start();

if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
}

include("../connection.php");

// Get patient info
$sqlmain= "select * from patient where pemail=?";
$stmt = $database->prepare($sqlmain);
$stmt->bind_param("s",$useremail);
$stmt->execute();
$userrow = $stmt->get_result();
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["pid"];
$username=$userfetch["pname"];

if($_POST){
    if(isset($_POST["booknow"])){
        $apponum=$_POST["apponum"];
        $scheduleid=$_POST["scheduleid"];
        $date=$_POST["date"];
        $scheduledate=$_POST["scheduledate"];
        $scheduletime=$_POST["scheduletime"];
        
        // VALIDATION 1: Check if patient already booked this specific slot
        $check_booking_sql = "SELECT * FROM appointment WHERE scheduleid=? AND pid=? AND status != 'cancelled'";
        $check_stmt = $database->prepare($check_booking_sql);
        $check_stmt->bind_param("ii", $scheduleid, $userid);
        $check_stmt->execute();
        $existing_booking = $check_stmt->get_result();
        
        if($existing_booking->num_rows > 0) {
            header("location: booking.php?id=".$scheduleid."&error=multiple_booking");
            exit();
        }
        
        // VALIDATION 2: Check for time clashes (same date and time)
        $check_clash_sql = "SELECT a.* FROM appointment a 
                           INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
                           WHERE a.pid=? AND s.scheduledate=? AND s.scheduletime=? AND a.status != 'cancelled'";
        $clash_stmt = $database->prepare($check_clash_sql);
        $clash_stmt->bind_param("iss", $userid, $scheduledate, $scheduletime);
        $clash_stmt->execute();
        $time_clash = $clash_stmt->get_result();
        
        if($time_clash->num_rows > 0) {
            header("location: booking.php?id=".$scheduleid."&error=timeclash");
            exit();
        }
        
        // VALIDATION 3: Check for same day appointments
        $check_same_day_sql = "SELECT a.* FROM appointment a 
                              INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
                              WHERE a.pid=? AND s.scheduledate=? AND a.status != 'cancelled'";
        $day_stmt = $database->prepare($check_same_day_sql);
        $day_stmt->bind_param("is", $userid, $scheduledate);
        $day_stmt->execute();
        $same_day = $day_stmt->get_result();
        
        if($same_day->num_rows > 0) {
            header("location: booking.php?id=".$scheduleid."&error=sameday");
            exit();
        }
        
        // VALIDATION 4: Check if slot is still available (using nop from schedule)
        $check_capacity_sql = "SELECT s.nop, COUNT(a.appoid) as booked_count 
                              FROM schedule s 
                              LEFT JOIN appointment a ON s.scheduleid = a.scheduleid AND a.status != 'cancelled' 
                              WHERE s.scheduleid = ? 
                              GROUP BY s.scheduleid";
        $capacity_stmt = $database->prepare($check_capacity_sql);
        $capacity_stmt->bind_param("i", $scheduleid);
        $capacity_stmt->execute();
        $capacity_result = $capacity_stmt->get_result();
        
        if($capacity_result->num_rows > 0) {
            $capacity_data = $capacity_result->fetch_assoc();
            $max_capacity = $capacity_data['nop'];
            $current_bookings = $capacity_data['booked_count'];
            
            if($current_bookings >= $max_capacity) {
                header("location: booking.php?id=".$scheduleid."&error=slotfull");
                exit();
            }
        }
        
        // VALIDATION 5: Check if appointment number is correct
        $check_apponum_sql = "SELECT COUNT(*) as current_count FROM appointment WHERE scheduleid=? AND status != 'cancelled'";
        $apponum_stmt = $database->prepare($check_apponum_sql);
        $apponum_stmt->bind_param("i", $scheduleid);
        $apponum_stmt->execute();
        $apponum_result = $apponum_stmt->get_result();
        $apponum_row = $apponum_result->fetch_assoc();
        $expected_apponum = $apponum_row['current_count'] + 1;
        
        if($apponum != $expected_apponum) {
            header("location: booking.php?id=".$scheduleid."&error=database");
            exit();
        }
        
        // If all validations pass, insert the appointment
        $sql2 = "INSERT INTO appointment(pid, apponum, scheduleid, appodate, status) VALUES (?, ?, ?, NOW(), 'scheduled')";
        $stmt = $database->prepare($sql2);
        $stmt->bind_param("iii", $userid, $apponum, $scheduleid);
        
        if($stmt->execute()){
            $new_appointment_id = $database->insert_id;
            header("location: appointment.php?action=booking-added&id=".$new_appointment_id);
        } else {
            header("location: booking.php?id=".$scheduleid."&error=database");
        }
    }
} else {
    header("location: schedule.php");
    exit();
}
?>