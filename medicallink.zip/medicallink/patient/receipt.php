<?php
session_start();

if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
}

include("../connection.php");
require_once("../email-config.php"); // Include email configuration

// Get patient info
$sqlmain= "select * from patient where pemail=?";
$stmt = $database->prepare($sqlmain);
$stmt->bind_param("s",$useremail);
$stmt->execute();
$userrow = $stmt->get_result();
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["pid"];
$username=$userfetch["pname"];

$appointment_id = $_GET['appointment_id'] ?? '';

if($appointment_id) {
    // Get appointment details
    $sql = "SELECT a.*, s.title, s.scheduledate, s.scheduletime, d.docname, d.docemail, p.pname, p.pemail 
            FROM appointment a 
            INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
            INNER JOIN doctor d ON s.docid = d.docid 
            INNER JOIN patient p ON a.pid = p.pid 
            WHERE a.appoid = ? AND a.pid = ?";
    $stmt = $database->prepare($sql);
    $stmt->bind_param("ii", $appointment_id, $userid);
    $stmt->execute();
    $appointment = $stmt->get_result()->fetch_assoc();
    
    if(!$appointment) {
        die("Appointment not found or access denied.");
    }
}

// Handle email sending
if($_POST && isset($_POST['send_receipt'])) {
    $email = $_POST['email'];
    $send_copy = isset($_POST['send_copy']) ? true : false;
    
    if(sendReceiptEmail($appointment, $email, $send_copy ? $useremail : null)) {
        header("location: appointment.php?action=receipt-sent&id=".$appointment_id);
    } else {
        header("location: receipt.php?appointment_id=".$appointment_id."&error=email_failed");
    }
}

// UPDATED FUNCTION: Uses PHPMailer instead of mail()
function sendReceiptEmail($appointment, $to_email, $cc_email = null) {
    // Prepare appointment data for the enhanced function
    $appointment_data = [
        'appoid' => $appointment['appoid'],
        'appodate' => $appointment['appodate'],
        'pname' => $appointment['pname'],
        'docname' => $appointment['docname'],
        'title' => $appointment['title'],
        'scheduledate' => $appointment['scheduledate'],
        'scheduletime' => $appointment['scheduletime'],
        'apponum' => $appointment['apponum']
    ];
    
    // Use our enhanced email function from email-config.php
    return sendReceiptEmailEnhanced($appointment_data, $to_email, $cc_email);
}

// REMOVED: The duplicate generateReceiptHTML() function since it's already in email-config.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Receipt</title>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .receipt-container {
            animation: transitionIn-Y-over 0.5s;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin: 20px;
        }
        .receipt-header {
            text-align: center;
            background: #007bff;
            color: white;
            padding: 20px;
            border-radius: 10px 10px 0 0;
            margin: -30px -30px 20px -30px;
        }
        .receipt-details {
            background: #f8f9fa;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        .detail-label {
            font-weight: bold;
            color: #555;
        }
        .total-section {
            background: #e8f5e8;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            margin: 20px 0;
        }
        .email-form {
            background: #f0f2f5;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="menu">
            <?php include("patientnav.php"); ?>
        </div>

        <div class="dash-body">
            <table border="0" width="100%" style="border-spacing: 0;margin: 0;padding: 0;margin-top: 25px;">
                <tr>
                    <td width="13%">
                        <a href="appointment.php">
                            <button class="login-btn btn-primary-soft btn btn-icon-back" style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px">
                                <font class="tn-in-text">Back</font>
                            </button>
                        </a>
                    </td>
                    <td>
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;">Appointment Receipt</p>
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php echo date('Y-m-d'); ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button class="btn-label" style="display: flex;justify-content: center;align-items: center;">
                            <img src="../img/calendar.svg" width="100%">
                        </button>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="4">
                        <center>
                            <div class="receipt-container">
                                <div class="receipt-header">
                                    <h2>Medical Link - Appointment Receipt</h2>
                                    <p>Thank you for choosing our medical services</p>
                                </div>
                                
                                <?php if($appointment): ?>
                                <div class="receipt-details">
                                    <div class="detail-row">
                                        <span class="detail-label">Receipt Number:</span>
                                        <span>OC-000-<?php echo $appointment['appoid']; ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Booking Date:</span>
                                        <span><?php echo date('F j, Y', strtotime($appointment['appodate'])); ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Patient Name:</span>
                                        <span><?php echo $appointment['pname']; ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Doctor:</span>
                                        <span>Dr. <?php echo $appointment['docname']; ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Session:</span>
                                        <span><?php echo $appointment['title']; ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Appointment Date:</span>
                                        <span><?php echo date('F j, Y', strtotime($appointment['scheduledate'])); ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Appointment Time:</span>
                                        <span><?php echo date('g:i A', strtotime($appointment['scheduletime'])); ?></span>
                                    </div>
                                    <div class="detail-row">
                                        <span class="detail-label">Appointment Number:</span>
                                        <span><?php echo $appointment['apponum']; ?></span>
                                    </div>
                                </div>
                                
                                <div class="total-section">
                                    Consultation Fee: RM 150.00
                                </div>
                                
                                <div class="email-form">
                                    <h3>Send Receipt to Email</h3>
                                    <form method="POST">
                                        <div class="form-group">
                                            <label class="form-label">Email Address:</label>
                                            <input type="email" name="email" class="form-input" 
                                                   value="<?php echo $useremail; ?>" required 
                                                   placeholder="Enter email address to send receipt">
                                        </div>
                                        <div class="form-group">
                                            <div class="checkbox-group">
                                                <input type="checkbox" name="send_copy" id="send_copy" checked>
                                                <label for="send_copy">Send a copy to my email (<?php echo $useremail; ?>)</label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" name="send_receipt" class="login-btn btn-primary btn" 
                                                    style="padding: 12px 30px; font-size: 16px;">
                                                📧 Send Receipt via Email
                                            </button>
                                            <button type="button" onclick="window.print()" class="login-btn btn-primary-soft btn" 
                                                    style="padding: 12px 30px; font-size: 16px; margin-left: 10px;">
                                                🖨️ Print Receipt
                                            </button>
                                        </div>
                                    </form>
                                </div>
                                <?php else: ?>
                                <div style="text-align: center; padding: 40px;">
                                    <p>Appointment not found or access denied.</p>
                                    <a href="appointment.php" class="non-style-link">
                                        <button class="login-btn btn-primary-soft btn">Back to Appointments</button>
                                    </a>
                                </div>
                                <?php endif; ?>
                                
                                <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
                                    <p>This is an automated receipt. Please keep this for your records.</p>
                                    <p>Medical Link Clinic<br>
                                    Contact: +603-1234 5678 | Email: info@medicallink.com</p>
                                </div>
                            </div>
                        </center>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>