<?php
session_start();
include("../connection.php");

if(isset($_SESSION["user"]) && $_SESSION['usertype']=='p') {
    $useremail = $_SESSION["user"];
    
    // Get patient ID
    $sqlmain = "SELECT pid FROM patient WHERE pemail=?";
    $stmt = $database->prepare($sqlmain);
    $stmt->bind_param("s", $useremail);
    $stmt->execute();
    $result = $stmt->get_result();
    $userfetch = $result->fetch_assoc();
    $userid = $userfetch["pid"];
    
    if(isset($_FILES['patient-picture']) && $_FILES['patient-picture']['error'] == 0) {
        $target_dir = "../img/patients/";
        
        // Create directory if it doesn't exist
        if(!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        // Generate unique filename
        $file_extension = strtolower(pathinfo($_FILES["patient-picture"]["name"], PATHINFO_EXTENSION));
        $allowed_extensions = array("jpg", "jpeg", "png", "gif");
        
        // Check if file is an image
        $check = getimagesize($_FILES["patient-picture"]["tmp_name"]);
        if($check === false) {
            header("location: settings.php?upload=notimage");
            exit();
        }
        
        // Check file extension
        if(!in_array($file_extension, $allowed_extensions)) {
            header("location: settings.php?upload=invalidformat");
            exit();
        }
        
        // Check file size (max 5MB)
        if($_FILES["patient-picture"]["size"] > 5000000) {
            header("location: settings.php?upload=filetoolarge");
            exit();
        }
        
        // Generate unique filename
        $new_filename = "patient_" . $userid . "_" . time() . "." . $file_extension;
        $target_file = $target_dir . $new_filename;
        
        // Move uploaded file
        if(move_uploaded_file($_FILES["patient-picture"]["tmp_name"], $target_file)) {
            // Update database with new picture path
            $picture_path = "img/patients/" . $new_filename;
            $sql = "UPDATE patient SET ppicture = ? WHERE pid = ?";
            $stmt = $database->prepare($sql);
            $stmt->bind_param("si", $picture_path, $userid);
            
            if($stmt->execute()) {
                header("location: settings.php?upload=success");
            } else {
                header("location: settings.php?upload=dberror");
            }
        } else {
            header("location: settings.php?upload=error");
        }
    } else {
        header("location: settings.php?upload=noimage");
    }
} else {
    header("location: ../login.php");
}
?>