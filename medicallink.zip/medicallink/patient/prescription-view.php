<?php
session_start();

if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
}

include("../connection.php");

$sqlmain= "select * from patient where pemail=?";
$stmt = $database->prepare($sqlmain);
$stmt->bind_param("s",$useremail);
$stmt->execute();
$userrow = $stmt->get_result();
$userfetch=$userrow->fetch_assoc();

$userid= $userfetch["pid"];
$username=$userfetch["pname"];

// Get patient picture if exists
$patient_picture = "../img/user.png";
if(isset($userfetch["ppicture"]) && !empty($userfetch["ppicture"])) {
    $patient_picture = "../" . $userfetch["ppicture"];
}

$prescription_id = $_GET['id'];

// Get prescription details with access control
$stmt = $database->prepare("
    SELECT p.*, doc.docname as doctor_name, doc.docemail as doctor_email,
           app.apponum, app.appodate
    FROM prescriptions p
    INNER JOIN doctor doc ON p.doctor_id = doc.docid
    LEFT JOIN appointment app ON p.appointment_id = app.appoid
    WHERE p.prescription_id = ? AND p.patient_id = ?
");

$stmt->bind_param("ii", $prescription_id, $userid);
$stmt->execute();
$prescription = $stmt->get_result()->fetch_assoc();

if (!$prescription) {
    die("Prescription not found or access denied.");
}

// Get prescription items
$items_stmt = $database->prepare("SELECT * FROM prescription_items WHERE prescription_id = ?");
$items_stmt->bind_param("i", $prescription_id);
$items_stmt->execute();
$items = $items_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Prescription</title>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../css/prescription.css">
    <style>
        .prescription-view-container {
            animation: transitionIn-Y-over 0.5s;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px">
                                    <div class="profile-picture-container">
                                        <img src="<?php echo $patient_picture; ?>" alt="Patient Picture" width="100%" style="border-radius:50%">
                                    </div>
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title"><?php echo substr($username,0,13)  ?>..</p>
                                    <p class="profile-subtitle"><?php echo substr($useremail,0,22)  ?></p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-home" >
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Home</p></a></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-doctor">
                        <a href="doctors.php" class="non-style-link-menu"><div><p class="menu-text">All Doctors</p></a></div>
                    </td>
                </tr>
                
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">Book Appointment</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Bookings</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-prescription menu-active menu-icon-prescription-active">
                        <a href="prescription-list.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">My Prescriptions</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></a></div>
                    </td>
                </tr>
            </table>
        </div>
        <div class="dash-body" style="margin-top: 15px">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;" >
                <tr>
                    <td colspan="1" class="nav-bar" >
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;margin-left:20px;">Prescription Details</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <center>
                            <div class="prescription-container prescription-view-container">
                                <div class="prescription-header">
                                    <h2>Medical Prescription</h2>
                                    <div class="prescription-info">
                                        <p><strong>Prescription ID:</strong> #<?php echo $prescription['prescription_id']; ?></p>
                                        <p><strong>Date:</strong> <?php echo date('F j, Y', strtotime($prescription['prescription_date'])); ?></p>
                                        <p><strong>Doctor:</strong> Dr. <?php echo $prescription['doctor_name']; ?></p>
                                        <p><strong>Patient:</strong> <?php echo $username; ?></p>
                                        <?php if ($prescription['apponum']): ?>
                                            <p><strong>Appointment:</strong> #<?php echo $prescription['apponum']; ?> (<?php echo date('F j, Y', strtotime($prescription['appodate'])); ?>)</p>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="diagnosis-section">
                                    <h3>Diagnosis</h3>
                                    <p><?php echo nl2br(htmlspecialchars($prescription['diagnosis'])); ?></p>
                                </div>

                                <div class="medicines-section">
                                    <h3>Medications</h3>
                                    <table class="medicines-table">
                                        <thead>
                                            <tr>
                                                <th>Medicine</th>
                                                <th>Dosage</th>
                                                <th>Frequency</th>
                                                <th>Duration</th>
                                                <th>Instructions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while ($item = $items->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['medicine_name']); ?></td>
                                                <td><?php echo htmlspecialchars($item['dosage']); ?></td>
                                                <td><?php echo htmlspecialchars($item['frequency']); ?></td>
                                                <td><?php echo htmlspecialchars($item['duration']); ?></td>
                                                <td><?php echo nl2br(htmlspecialchars($item['instructions'])); ?></td>
                                            </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>

                                <?php if (!empty($prescription['notes'])): ?>
                                <div class="notes-section">
                                    <h3>Additional Notes</h3>
                                    <p><?php echo nl2br(htmlspecialchars($prescription['notes'])); ?></p>
                                </div>
                                <?php endif; ?>

                                <div class="status-section">
                                    <p><strong>Status:</strong> <span style="color: <?php echo $prescription['status'] == 'active' ? '#28a745' : ($prescription['status'] == 'completed' ? '#007bff' : '#dc3545'); ?>; font-weight: bold;"><?php echo ucfirst($prescription['status']); ?></span></p>
                                </div>

                                <div class="actions">
                                    <button onclick="window.print()" class="btn-primary">Print Prescription</button>
                                    <a href="prescription-list.php" class="btn-secondary">Back to List</a>
                                </div>
                            </div>
                        </center>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>