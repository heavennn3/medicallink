<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
        
    <title>Appointments</title>
    <style>
        .popup{ 
            animation: transitionIn-Y-bottom 0.5s;
            }elseif($action=='receipt-sent'){
    echo '
    <div id="popup1" class="overlay">
            <div class="popup">
            <center>
            <br><br>
                <h2>Receipt Sent Successfully!</h2>
                <a class="close" href="appointment.php">&times;</a>
                <div class="content">
                Your appointment receipt has been sent to your email address.<br><br>
                    
                </div>
                <div style="display: flex;justify-content: center;">
                
                <a href="appointment.php" class="non-style-link"><button  class="btn-primary btn"  style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;"><font class="tn-in-text">&nbsp;&nbsp;OK&nbsp;&nbsp;</font></button></a>
                <br><br><br><br>
                </div>
            </center>
    </div>
    </div>
    ';
}

        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .status-badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}
.status-upcoming { background: #e3f2fd; color: #1976d2; }
.status-completed { background: #e8f5e8; color: #2e7d32; }
.status-cancelled { background: #ffebee; color: #c62828; }
</style>
</head>
<body>
    <?php
session_start();

// Enhanced session checking
if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" || $_SESSION['usertype']!='p'){
        header("location: ../login.php");
        exit();
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
    exit();
}

include("../connection.php");

$sqlmain= "select * from patient where pemail=?";
$stmt = $database->prepare($sqlmain);
$stmt->bind_param("s",$useremail);
$stmt->execute();
$userrow = $stmt->get_result();
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["pid"];
$username=$userfetch["pname"];

// Get patient picture if exists
$patient_picture = "../img/user.png";
if(isset($userfetch["ppicture"]) && !empty($userfetch["ppicture"])) {
    $patient_picture = "../" . $userfetch["ppicture"];
    if (!file_exists($patient_picture)) {
        $patient_picture = "../img/user.png";
    }
}

// Build base query with prepared statements
$sqlmain = "SELECT appointment.appoid, schedule.scheduleid, schedule.title, doctor.docname, 
                   patient.pname, schedule.scheduledate, schedule.scheduletime, 
                   appointment.apponum, appointment.appodate, appointment.status,
                   doctor.docid
            FROM schedule 
            INNER JOIN appointment ON schedule.scheduleid=appointment.scheduleid 
            INNER JOIN patient ON patient.pid=appointment.pid 
            INNER JOIN doctor ON schedule.docid=doctor.docid  
            WHERE patient.pid = ?";

$params = [$userid];
$types = "i";

if($_POST && !empty($_POST["sheduledate"])){
    $sheduledate = $_POST["sheduledate"];
    // Validate date format to prevent SQL injection
    if (DateTime::createFromFormat('Y-m-d', $sheduledate) !== false) {
        $sqlmain .= " AND schedule.scheduledate = ?";
        $params[] = $sheduledate;
        $types .= "s";
    }
}

$sqlmain .= " ORDER BY schedule.scheduledate DESC, schedule.scheduletime ASC";

// Use prepared statement
$stmt = $database->prepare($sqlmain);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
    ?>
    
    <div class="container">
        <div class="menu">
            <?php include("patientnav.php"); ?>
        </div>
        
        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
                <tr >
                    <td width="13%" >
                    <a href="appointment.php" ><button  class="login-btn btn-primary-soft btn btn-icon-back"  style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                    </td>
                    <td>
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;">My Bookings history</p>
                                           
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 
                        date_default_timezone_set('Asia/Kuala_Lumpur');
                        $today = date('Y-m-d');
                        echo $today;
                        ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button  class="btn-label"  style="display: flex;justify-content: center;align-items: center;"><img src="../img/calendar.svg" width="100%"></button>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="4" style="padding-top:10px;width: 100%;" >
                        <p class="heading-main12" style="margin-left: 45px;font-size:18px;color:rgb(49, 49, 49)">My Bookings (<?php echo $result->num_rows; ?>)</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="4" style="padding-top:0px;width: 100%;" >
                        <center>
                        <table class="filter-container" border="0" >
                        <tr>
                           <td width="10%">
                           </td> 
                        <td width="5%" style="text-align: center;">
                        Date:
                        </td>
                        <td width="30%">
                        <form action="" method="post">
                            <input type="date" name="sheduledate" id="date" class="input-text filter-container-items" style="margin: 0;width: 95%;">
                        </td>
                        
                    <td width="12%">
                        <input type="submit"  name="filter" value=" Filter" class=" btn-primary-soft btn button-icon btn-filter"  style="padding: 15px; margin :0;width:100%">
                        </form>
                    </td>
                    </tr>
                            </table>
                        </center>
                    </td>
                </tr>
                  
                <tr>
                   <td colspan="4">
                       <center>
                        <div class="abc scroll">
                        <table width="93%" class="sub-table scrolldown" border="0" style="border:none">
                        
                        <tbody>
                            <?php
                                if($result->num_rows==0){
                                    echo '<tr>
                                    <td colspan="7">
                                    <br><br><br><br>
                                    <center>
                                    <img src="../img/notfound.svg" width="25%">
                                    
                                    <br>
                                    <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">We  couldnt find anything related to your keywords !</p>
                                    <a class="non-style-link" href="appointment.php"><button  class="login-btn btn-primary-soft btn"  style="display: flex;justify-content: center;align-items: center;margin-left:20px;">&nbsp; Show all Appointments &nbsp;</font></button>
                                    </a>
                                    </center>
                                    <br><br><br><br>
                                    </td>
                                    </tr>';
                                }
                                else{
                                    for ( $x=0; $x<($result->num_rows);$x++){
                                        echo "<tr>";
                                        for($q=0;$q<3;$q++){
                                            $row=$result->fetch_assoc();
                                            if (!isset($row)){
                                            break;
                                            };
                                            $scheduleid=$row["scheduleid"];
                                            $title=$row["title"];
                                            $docname=$row["docname"];
                                            $sheduledate=$row["scheduledate"];
                                            $scheduletime=$row["scheduletime"];
                                            $apponum=$row["apponum"];
                                            $appodate=$row["appodate"];
                                            $appoid=$row["appoid"];
    
                                            if($scheduleid==""){
                                                break;
                                            }
    
                                            // Get appointment status and check if it's in the future
$status = isset($row["status"]) ? $row["status"] : "scheduled";
$appointment_datetime = $sheduledate . ' ' . $scheduletime;
$current_datetime = date('Y-m-d H:i:s');
$is_future_appointment = (strtotime($appointment_datetime) > strtotime($current_datetime));
$is_today = (date('Y-m-d') == $sheduledate);

// Status badge
$status_badge = '';
switch($status) {
    case 'completed':
        $status_badge = '<span class="status-badge status-completed">Completed</span>';
        break;
    case 'cancelled':
        $status_badge = '<span class="status-badge status-cancelled">Cancelled</span>';
        break;
    default:
        if ($is_future_appointment) {
            $status_badge = '<span class="status-badge status-upcoming">Upcoming</span>';
        } else {
            $status_badge = '<span class="status-badge status-completed">Completed</span>';
        }
}

echo '
<td style="width: 25%;">
        <div  class="dashboard-items search-items"  >
        
            <div style="width:100%;">
            <div class="h3-search">
                        '.$status_badge.'<br>
                        Booking Date: '.substr($appodate,0,30).'<br>
                        Reference Number: OC-000-'.$appoid.'
                    </div>
                    <div class="h1-search">
                        '.substr($title,0,21).'<br>
                    </div>
                    <div class="h3-search">
                        Doctor: '.substr($docname,0,30).'
                    </div>
                    <div class="h3-search">
                        Appointment Slot: <div class="h1-search">0'.$apponum.'</div>
                    </div>
                    
                    <div class="h4-search">
                        Scheduled Date: '.$sheduledate.'<br>Time: <b>@'.substr($scheduletime,0,5).'</b>
                    </div>
                    <br>';
                    
// Show chat button only for today's and future appointments
if ($is_future_appointment || $is_today) {
    echo '<a href="chat.php?appointment_id='.$appoid.'" ><button  class="login-btn btn-primary-soft btn "  style="padding-top:11px;padding-bottom:11px;width:100%;margin-bottom:5px;background:#28a745;"><font class="tn-in-text">💬 Chat with Doctor</font></button></a>';
}

// Show cancel button only for future appointments 
// Show receipt button for completed appointments
if ($status == 'completed') {
    echo '<a href="receipt.php?appointment_id='.$appoid.'" ><button  class="login-btn btn-primary-soft btn "  style="padding-top:11px;padding-bottom:11px;width:100%;margin-bottom:5px;background:#17a2b8;"><font class="tn-in-text">🧾 Get Receipt</font></button></a>';
}

if ($is_future_appointment && $status != 'cancelled') {
    // Check if cancellation is allowed (at least 2 hours before appointment)
    $hours_before = (strtotime($appointment_datetime) - strtotime($current_datetime)) / 3600;
    if ($hours_before > 2) {
        echo '<a href="appointment.php?action=drop&id='.$appoid.'&title='.urlencode($title).'&doc='.urlencode($docname).'&date='.$sheduledate.'&time='.$scheduletime.'" >
            <button  class="login-btn btn-primary-soft btn "  style="padding-top:11px;padding-bottom:11px;width:100%">
                <font class="tn-in-text">Cancel Booking</font>
            </button>
        </a>';
    } else {
        echo '<button class="login-btn btn-primary-soft btn" style="padding-top:11px;padding-bottom:11px;width:100%;background:#6c757d;" disabled>
            <font class="tn-in-text">Cancellation Not Allowed</font>
        </button>';
    }
}

echo '
            </div>
        </div>
    </td>';
                                        }
                                        echo "</tr>";
                                    }
                                }
                            ?>
                            </tbody>
                        </table>
                        </div>
                        </center>
                   </td> 
                </tr>
            </table>
        </div>
    </div>
    <?php
    if($_GET){
        $id=$_GET["id"];
        $action=$_GET["action"];
        if($action=='booking-added'){
            echo '
            <div id="popup1" class="overlay">
                    <div class="popup">
                    <center>
                    <br><br>
                        <h2>Booking Successfully.</h2>
                        <a class="close" href="appointment.php">&times;</a>
                        <div class="content">
                        Your Appointment number is '.$id.'.<br><br>
                            
                        </div>
                        <div style="display: flex;justify-content: center;">
                        
                        <a href="appointment.php" class="non-style-link"><button  class="btn-primary btn"  style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;"><font class="tn-in-text">&nbsp;&nbsp;OK&nbsp;&nbsp;</font></button></a>
                        <br><br><br><br>
                        </div>
                    </center>
            </div>
            </div>
            ';
             }elseif($action=='drop'){
            $title = $_GET["title"];
            $docname = $_GET["doc"];
            $date = isset($_GET["date"]) ? $_GET["date"] : "";
            $time = isset($_GET["time"]) ? $_GET["time"] : "";
            
            // Check if cancellation is still allowed (at least 2 hours before appointment)
            $appointment_datetime = $date . ' ' . $time;
            $current_datetime = date('Y-m-d H:i:s');
            $hours_before = (strtotime($appointment_datetime) - strtotime($current_datetime)) / 3600;
            
            if ($hours_before <= 2) {
                echo '
                <div id="popup1" class="overlay">
                        <div class="popup">
                        <center>
                            <h2>Cancellation Not Allowed</h2>
                            <a class="close" href="appointment.php">&times;</a>
                            <div class="content">
                                You cannot cancel this appointment as it is less than 2 hours away.<br><br>
                                Please contact the clinic directly for assistance.
                            </div>
                            <div style="display: flex;justify-content: center;">
                            <a href="appointment.php" class="non-style-link"><button class="btn-primary btn" style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;"><font class="tn-in-text">&nbsp;&nbsp;OK&nbsp;&nbsp;</font></button></a>
                            </div>
                        </center>
                </div>
                </div>
                ';
                        } else {
                echo '
                <div id="popup1" class="overlay">
                        <div class="popup">
                        <center>
                            <h2>Are you sure?</h2>
                            <a class="close" href="appointment.php">&times;</a>
                            <div class="content">
                                You want to Cancel this Appointment?<br><br>
                                Session: &nbsp;<b>'.substr($title,0,40).'</b><br>
                                Doctor: &nbsp; <b>'.substr($docname,0,40).'</b><br>
                                Date: &nbsp; <b>'.$date.'</b><br>
                                Time: &nbsp; <b>'.$time.'</b><br><br>
                            </div>
                            <div style="display: flex;justify-content: center;">
                            <a href="delete-appointment.php?id='.$id.'" class="non-style-link"><button class="btn-primary btn" style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;"><font class="tn-in-text">&nbsp;Yes&nbsp;</font></button></a>&nbsp;&nbsp;&nbsp;
                            <a href="appointment.php" class="non-style-link"><button class="btn-primary btn" style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;"><font class="tn-in-text">&nbsp;&nbsp;No&nbsp;&nbsp;</font></button></a>
                            </div>
                        </center>
                </div>
                </div>
                ';
            }
        }elseif($action=='view'){
            $sqlmain= "select * from doctor where docid=?";
            $stmt = $database->prepare($sqlmain);
            $stmt->bind_param("i",$id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row=$result->fetch_assoc();
            $name=$row["docname"];
            $email=$row["docemail"];
            $spe=$row["specialties"];
            
            $sqlmain= "select sname from specialties where id=?";
            $stmt = $database->prepare($sqlmain);
            $stmt->bind_param("s",$spe);
            $stmt->execute();
            $spcil_res = $stmt->get_result();
            $spcil_array= $spcil_res->fetch_assoc();
            $spcil_name=$spcil_array["sname"];
            $nic=$row['docnic'];
            $tele=$row['doctel'];
            echo '
            <div id="popup1" class="overlay">
                    <div class="popup">
                    <center>
                        <h2></h2>
                        <a class="close" href="doctors.php">&times;</a>
                        <div class="content">
                            Medical Link Web App<br>
                            
                        </div>
                        <div style="display: flex;justify-content: center;">
                        <table width="80%" class="sub-table scrolldown add-doc-form-container" border="0">
                        
                            <tr>
                                <td>
                                    <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">View Details.</p><br><br>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="name" class="form-label">Name: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    '.$name.'<br><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="Email" class="form-label">Email: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                '.$email.'<br><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="nic" class="form-label">NIC: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                '.$nic.'<br><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="Tele" class="form-label">Phone Number: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                '.$tele.'<br><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="spec" class="form-label">Specialties: </label>
                                </td>
                            </tr>
                            <tr>
                            <td class="label-td" colspan="2">
                            '.$spcil_name.'<br><br>
                            </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="doctors.php"><input type="button" value="OK" class="login-btn btn-primary-soft btn" ></a>
                                </td>
                            </tr>
                        </table>
                        </div>
                    </center>
                    <br><br>
            </div>
            </div>
            ';  
        }
    }
    ?>
</body>
</html>