<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
        
    <title>Sessions</title>
    <style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .capacity-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            margin-top: 5px;
            display: inline-block;
        }
        .capacity-available { 
            background: #e8f5e8; 
            color: #2e7d32; 
        }
        .capacity-warning { 
            background: #fff3e0; 
            color: #ef6c00; 
        }
        .capacity-full { 
            background: #ffebee; 
            color: #c62828; 
        }
        .session-card {
            position: relative;
        }
        .book-btn:disabled {
            background: #cccccc !important;
            cursor: not-allowed;
        }
</style>
</head>
<body>
    <?php
    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
            header("location: ../login.php");
        }else{
            $useremail=$_SESSION["user"];
        }
    }else{
        header("location: ../login.php");
    }

    include("../connection.php");
    $sqlmain= "select * from patient where pemail=?";
    $stmt = $database->prepare($sqlmain);
    $stmt->bind_param("s",$useremail);
    $stmt->execute();
    $result = $stmt->get_result();
    $userfetch=$result->fetch_assoc();
    $userid= $userfetch["pid"];
    $username=$userfetch["pname"];
    
    // Get patient picture if exists - ADDED CODE
    $patient_picture = "../img/user.png";
    if(isset($userfetch["ppicture"]) && !empty($userfetch["ppicture"])) {
        $patient_picture = "../" . $userfetch["ppicture"];
        if (!file_exists($patient_picture)) {
            $patient_picture = "../img/user.png";
        }
    }
    
    date_default_timezone_set('Asia/Kuala_Lumpur');
    $today = date('Y-m-d');
 ?>
 <div class="container">
     <div class="menu">
     <table class="menu-container" border="0">
             <tr>
                 <td style="padding:10px" colspan="2">
                     <table border="0" class="profile-container">
                         <tr>
                             <td width="30%" style="padding-left:20px" >
                                 <!-- UPDATED PROFILE PICTURE CODE -->
                                 <div class="profile-picture-container">
                                     <img src="<?php echo htmlspecialchars($patient_picture); ?>" alt="Patient Picture" width="100%" style="border-radius:50%">
                                 </div>
                             </td>
                             <td style="padding:0px;margin:0px;">
                                 <p class="profile-title"><?php echo substr($username,0,13)  ?>..</p>
                                 <p class="profile-subtitle"><?php echo substr($useremail,0,22)  ?></p>
                             </td>
                         </tr>
                         <tr>
                             <td colspan="2">
                                 <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                             </td>
                         </tr>
                 </table>
                 </td>
             </tr>
             <tr class="menu-row" >
                    <td class="menu-btn menu-icon-home " >
                        <a href="index.php" class="non-style-link-menu "><div><p class="menu-text">Home</p></a></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-doctor">
                        <a href="doctors.php" class="non-style-link-menu"><div><p class="menu-text">All Doctors</p></a></div>
                    </td>
                </tr>
                
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session menu-active menu-icon-session-active">
                        <a href="schedule.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Book Appointment</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Bookings</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></a></div>
                    </td>
                </tr>
                
            </table>
        </div>
        <?php
        // FIXED: Use prepared statements to prevent SQL injection and type errors
        $sqlmain = "SELECT schedule.*, doctor.docname, doctor.docemail 
                   FROM schedule 
                   INNER JOIN doctor ON schedule.docid=doctor.docid 
                   WHERE schedule.scheduledate >= ? 
                   ORDER BY schedule.scheduledate ASC";
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("s", $today);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $sqlpt1 = "";
        $insertkey = "";
        $q = '';
        $searchtype = "All";
        
        if($_POST && !empty($_POST["search"])){
            $keyword = $_POST["search"];
            $insertkey = $keyword;
            $searchtype = "Search Result : ";
            $q = '"';
            
            // FIXED: Separate conditions for text fields and date fields
            $sqlmain = "SELECT schedule.*, doctor.docname, doctor.docemail 
                       FROM schedule 
                       INNER JOIN doctor ON schedule.docid=doctor.docid 
                       WHERE schedule.scheduledate >= ? 
                       AND (doctor.docname LIKE ? 
                            OR doctor.docname LIKE ? 
                            OR doctor.docname LIKE ? 
                            OR schedule.title LIKE ? 
                            OR schedule.title LIKE ? 
                            OR schedule.title LIKE ?)
                       ORDER BY schedule.scheduledate ASC";
            
            $stmt = $database->prepare($sqlmain);
            $search_term1 = $keyword;
            $search_term2 = $keyword . '%';
            $search_term3 = '%' . $keyword . '%';
            $stmt->bind_param("sssssss", $today, $search_term1, $search_term2, $search_term3, $search_term1, $search_term2, $search_term3);
            $stmt->execute();
            $result = $stmt->get_result();
        }

        ?>
                  
        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
                <tr >
                    <td width="13%" >
                    <a href="schedule.php" ><button  class="login-btn btn-primary-soft btn btn-icon-back"  style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                    </td>
                    <td >
                            <form action="" method="post" class="header-search">
                                <input type="search" name="search" class="input-text header-searchbar" placeholder="Search Doctor name or Session Title" list="doctors" value="<?php echo htmlspecialchars($insertkey) ?>">&nbsp;&nbsp;
                                <?php
                                    echo '<datalist id="doctors">';
                                    $list11 = $database->query("SELECT DISTINCT docname FROM doctor");
                                    $list12 = $database->query("SELECT DISTINCT title FROM schedule");

                                    for ($y=0;$y<$list11->num_rows;$y++){
                                        $row00=$list11->fetch_assoc();
                                        $d=$row00["docname"];
                                        echo "<option value='$d'><br/>";
                                    };

                                    for ($y=0;$y<$list12->num_rows;$y++){
                                        $row00=$list12->fetch_assoc();
                                        $d=$row00["title"];
                                        echo "<option value='$d'><br/>";
                                    };

                                echo ' </datalist>';
                                ?>
                                
                                <input type="Submit" value="Search" class="login-btn btn-primary btn" style="padding-left: 25px;padding-right: 25px;padding-top: 10px;padding-bottom: 10px;">
                            </form>
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 
                                echo $today;
                            ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button  class="btn-label"  style="display: flex;justify-content: center;align-items: center;"><img src="../img/calendar.svg" width="100%"></button>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="4" style="padding-top:10px;width: 100%;" >
                        <p class="heading-main12" style="margin-left: 45px;font-size:18px;color:rgb(49, 49, 49)"><?php echo $searchtype." Sessions"."(".$result->num_rows.")"; ?> </p>
                        <p class="heading-main12" style="margin-left: 45px;font-size:22px;color:rgb(49, 49, 49)"><?php echo $q.$insertkey.$q ; ?> </p>
                    </td>
                </tr>
                
                <tr>
                   <td colspan="4">
                       <center>
                        <div class="abc scroll">
                        <table width="100%" class="sub-table scrolldown" border="0" style="padding: 50px;border:none">
                            
                        <tbody>
                            <?php
                                if($result->num_rows==0){
                                    echo '<tr>
                                    <td colspan="4">
                                    <br><br><br><br>
                                    <center>
                                    <img src="../img/notfound.svg" width="25%">
                                    
                                    <br>
                                    <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">We  couldnt find anything related to your keywords !</p>
                                    <a class="non-style-link" href="schedule.php"><button  class="login-btn btn-primary-soft btn"  style="display: flex;justify-content: center;align-items: center;margin-left:20px;">&nbsp; Show all Sessions &nbsp;</font></button>
                                    </a>
                                    </center>
                                    <br><br><br><br>
                                    </td>
                                    </tr>';
                                }
                                else{
                                    for ( $x=0; $x<($result->num_rows);$x++){
                                        echo "<tr>";
                                        for($q=0;$q<3;$q++){
                                            $row=$result->fetch_assoc();
                                            if (!isset($row)){
                                                break;
                                            };
                                            $scheduleid=$row["scheduleid"];
                                            $title=$row["title"];
                                            $docname=$row["docname"];
                                            $sheduledate=$row["scheduledate"];
                                            $scheduletime=$row["scheduletime"];
                                            $nop=$row["nop"]; // Get the max capacity

                                            if($scheduleid==""){
                                                break;
                                            }

                                            // Get current bookings count for this session
                                            $bookings_query = "SELECT COUNT(*) as booked_count FROM appointment WHERE scheduleid=? AND status != 'cancelled'";
                                            $bookings_stmt = $database->prepare($bookings_query);
                                            $bookings_stmt->bind_param("i", $scheduleid);
                                            $bookings_stmt->execute();
                                            $bookings_result = $bookings_stmt->get_result();
                                            $bookings_data = $bookings_result->fetch_assoc();
                                            $booked_count = $bookings_data['booked_count'];
                                            $available_slots = $nop - $booked_count;

                                            // Determine capacity status
                                            $capacity_class = 'capacity-available';
                                            $capacity_text = $available_slots . ' slots available';
                                            
                                            if ($available_slots <= 0) {
                                                $capacity_class = 'capacity-full';
                                                $capacity_text = 'FULLY BOOKED';
                                            } elseif ($available_slots <= ($nop * 0.2)) {
                                                $capacity_class = 'capacity-warning';
                                                $capacity_text = 'Only ' . $available_slots . ' left!';
                                            }

                                            // Check if patient already booked this session
                                            $check_booking_sql = "SELECT * FROM appointment WHERE scheduleid=? AND pid=? AND status != 'cancelled'";
                                            $check_stmt = $database->prepare($check_booking_sql);
                                            $check_stmt->bind_param("ii", $scheduleid, $userid);
                                            $check_stmt->execute();
                                            $existing_booking = $check_stmt->get_result();
                                            
                                            $can_book = ($available_slots > 0) && ($existing_booking->num_rows == 0);

                                            echo '
                                            <td style="width: 25%;">
                                                    <div  class="dashboard-items search-items session-card"  >
                                                    
                                                        <div style="width:100%">
                                                                <div class="h1-search">
                                                                    '.substr($title,0,21).'
                                                                </div><br>
                                                                <div class="h3-search">
                                                                    '.substr($docname,0,30).'
                                                                </div>
                                                                <div class="h4-search">
                                                                    '.$sheduledate.'<br>Starts: <b>@'.substr($scheduletime,0,5).'</b>
                                                                </div>
                                                                <div class="h4-search">
                                                                    Max Capacity: <b>'.$nop.' patients</b>
                                                                </div>
                                                                <div class="capacity-badge '.$capacity_class.'">
                                                                    '.$capacity_text.' ('.$booked_count.'/'.$nop.')
                                                                </div>
                                                                <br>';
                                            
                                            if ($can_book) {
                                                echo '<a href="booking.php?id='.$scheduleid.'" ><button class="login-btn btn-primary-soft btn" style="padding-top:11px;padding-bottom:11px;width:100%"><font class="tn-in-text">Book Now</font></button></a>';
                                            } else {
                                                if ($existing_booking->num_rows > 0) {
                                                    echo '<button class="login-btn btn-primary-soft btn book-btn" style="padding-top:11px;padding-bottom:11px;width:100%;background:#6c757d;" disabled><font class="tn-in-text">Already Booked</font></button>';
                                                } else {
                                                    echo '<button class="login-btn btn-primary-soft btn book-btn" style="padding-top:11px;padding-bottom:11px;width:100%;background:#6c757d;" disabled><font class="tn-in-text">Fully Booked</font></button>';
                                                }
                                            }

                                            echo '
                                                        </div>
                                                                
                                                    </div>
                                                </td>';
                                        }
                                        echo "</tr>";
                                    }
                                }
                            ?>
                            </tbody>
                        </table>
                        </div>
                        </center>
                   </td> 
                </tr>
            </table>
        </div>
    </div>
</body>
</html>