<?php
function checkAppointmentConflict($database, $patient_id, $doctor_id, $schedule_date, $schedule_time) {
    // Check if patient already has an appointment at the same time with any doctor
    $sql = "SELECT a.appoid, d.docname, s.scheduledate, s.scheduletime 
            FROM appointment a 
            INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
            INNER JOIN doctor d ON s.docid = d.docid 
            WHERE a.pid = ? AND s.scheduledate = ? AND s.scheduletime = ? AND a.status != 'cancelled'";
    
    $stmt = $database->prepare($sql);
    $stmt->bind_param("iss", $patient_id, $schedule_date, $schedule_time);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $conflict = $result->fetch_assoc();
        return "You already have an appointment with Dr. " . $conflict['docname'] . " on " . $conflict['scheduledate'] . " at " . $conflict['scheduletime'];
    }
    
    // Check if patient has more than 3 upcoming appointments
    $sql = "SELECT COUNT(*) as upcoming_count 
            FROM appointment a 
            INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
            WHERE a.pid = ? AND a.status != 'cancelled' 
            AND (s.scheduledate > CURDATE() OR (s.scheduledate = CURDATE() AND s.scheduletime > CURTIME()))";
    
    $stmt = $database->prepare($sql);
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $upcoming = $result->fetch_assoc();
    
    if ($upcoming['upcoming_count'] >= 3) {
        return "You cannot have more than 3 upcoming appointments at the same time.";
    }
    
    return null; // No conflict
}
?>