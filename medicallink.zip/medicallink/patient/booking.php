<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
        
    <title>Sessions</title>
    <style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .error-message {
            background: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
            border-left: 4px solid #c62828;
            text-align: center;
        }
        .warning-message {
            background: #e8f5e8;
            color: #2e7d32;
            padding: 15px;
            border-radius: 5px;
            margin: 15px 0;
            border-left: 4px solid #2e7d32;
            text-align: center;
        }
        .capacity-info {
            background: #e3f2fd;
            color: #1976d2;
            padding: 8px;
            border-radius: 5px;
            margin: 10px 0;
            text-align: center;
            font-weight: bold;
        }
        .capacity-full {
            background: #ffebee;
            color: #c62828;
        }
        .capacity-warning {
            background: #fff3e0;
            color: #ef6c00;
        }
</style>
</head>
<body>
    <?php
    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
            header("location: ../login.php");
        }else{
            $useremail=$_SESSION["user"];
        }
    }else{
        header("location: ../login.php");
    }

    include("../connection.php");
    $sqlmain= "select * from patient where pemail=?";
    $stmt = $database->prepare($sqlmain);
    $stmt->bind_param("s",$useremail);
    $stmt->execute();
    $result = $stmt->get_result();
    $userfetch=$result->fetch_assoc();
    $userid= $userfetch["pid"];
    $username=$userfetch["pname"];

    date_default_timezone_set('Asia/Kuala_Lumpur');
    $today = date('Y-m-d');

    if(isset($_GET['error'])){
        $error = $_GET['error'];
        $error_messages = [
            'timeclash' => 'You already have an appointment at this date and time!',
            'sameday' => 'You already have an appointment on this day! Please choose another date.',
            'slotfull' => 'This appointment slot is already full! Please choose another time.',
            'database' => 'Database error. Please try again.',
            'multiple_booking' => 'You have already booked this appointment slot!'
        ];
        if(isset($error_messages[$error])){
            echo '<div class="error-message" style="text-align: center; margin: 20px;">'.$error_messages[$error].'</div>';
        }
    }

    if(isset($_GET['success'])){
        echo '<div class="warning-message" style="text-align: center; margin: 20px;">Appointment booked successfully!</div>';
    }
 ?>
 <div class="container">
     <div class="menu">
     <table class="menu-container" border="0">
             <tr>
                 <td style="padding:10px" colspan="2">
                     <table border="0" class="profile-container">
                         <tr>
                             <td width="30%" style="padding-left:20px" >
                                 <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                             </td>
                             <td style="padding:0px;margin:0px;">
                                 <p class="profile-title"><?php echo substr($username,0,13)  ?>..</p>
                                 <p class="profile-subtitle"><?php echo substr($useremail,0,22)  ?></p>
                             </td>
                         </tr>
                         <tr>
                             <td colspan="2">
                                 <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                             </td>
                         </tr>
                 </table>
                 </td>
             </tr>
             <tr class="menu-row" >
                    <td class="menu-btn menu-icon-home " >
                        <a href="index.php" class="non-style-link-menu "><div><p class="menu-text">Home</p></a></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-doctor">
                        <a href="doctors.php" class="non-style-link-menu"><div><p class="menu-text">All Doctors</p></a></div>
                    </td>
                </tr>
                
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session menu-active menu-icon-session-active">
                        <a href="schedule.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Book Appointment</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Bookings</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></a></div>
                    </td>
                </tr>
                
            </table>
        </div>
        
        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
                <tr >
                    <td width="13%" >
                    <a href="schedule.php" ><button  class="login-btn btn-primary-soft btn btn-icon-back"  style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                    </td>
                    <td >
                            <form action="schedule.php" method="post" class="header-search">

                                        <input type="search" name="search" class="input-text header-searchbar" placeholder="Search Doctor name or Email or Date (YYYY-MM-DD)" list="doctors" >&nbsp;&nbsp;
                                        <?php
                                            echo '<datalist id="doctors">';
                                            $list11 = $database->query("select DISTINCT * from  doctor;");
                                            $list12 = $database->query("select DISTINCT * from  schedule GROUP BY title;");

                                            for ($y=0;$y<$list11->num_rows;$y++){
                                                $row00=$list11->fetch_assoc();
                                                $d=$row00["docname"];
                                               
                                                echo "<option value='$d'><br/>";
                                               
                                            };

                                            for ($y=0;$y<$list12->num_rows;$y++){
                                                $row00=$list12->fetch_assoc();
                                                $d=$row00["title"];
                                               
                                                echo "<option value='$d'><br/>";
                                                                                         };

                                        echo ' </datalist>';
            ?>
                                
                                        <input type="Submit" value="Search" class="login-btn btn-primary btn" style="padding-left: 25px;padding-right: 25px;padding-top: 10px;padding-bottom: 10px;">
                                        </form>
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 
                                
                                echo $today;
                        ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button  class="btn-label"  style="display: flex;justify-content: center;align-items: center;"><img src="../img/calendar.svg" width="100%"></button>
                    </td>

                </tr>
                
                <tr>
                    <td colspan="4" style="padding-top:10px;width: 100%;" >
                        
                    </td>
                    
                </tr>
                
                <tr>
                   <td colspan="4">
                       <center>
                        <div class="abc scroll">
                        <table width="100%" class="sub-table scrolldown" border="0" style="padding: 50px;border:none">
                            
                        <tbody>
                            <?php
                            
                            if(($_GET)){
                                
                                if(isset($_GET["id"])){

                                    $id=$_GET["id"];

                                    $sqlmain= "select * from schedule inner join doctor on schedule.docid=doctor.docid where schedule.scheduleid=? order by schedule.scheduledate desc";
                                    $stmt = $database->prepare($sqlmain);
                                    $stmt->bind_param("i", $id);
                                    $stmt->execute();
                                    $result = $stmt->get_result();

                                    $row=$result->fetch_assoc();
                                    $scheduleid=$row["scheduleid"];
                                    $title=$row["title"];
                                    $docname=$row["docname"];
                                    $docemail=$row["docemail"];
                                    $sheduledate=$row["scheduledate"];
                                    $scheduletime=$row["scheduletime"];
                                    $nop=$row["nop"]; // Get the max capacity from schedule table
                                    
                                    // Get current bookings count for this session (excluding cancelled)
                                    $sql2="select COUNT(*) as booked_count from appointment where scheduleid=? and status != 'cancelled'";
                                    $stmt2 = $database->prepare($sql2);
                                    $stmt2->bind_param("i", $id);
                                    $stmt2->execute();
                                    $result12 = $stmt2->get_result();
                                    $booked_data = $result12->fetch_assoc();
                                    $booked_count = $booked_data["booked_count"];
                                    $apponum = $booked_count + 1;
                                    
                                    // Check if patient already booked this slot
                                    $check_booking_sql = "SELECT * FROM appointment WHERE scheduleid=? AND pid=? AND status != 'cancelled'";
                                    $check_stmt = $database->prepare($check_booking_sql);
                                    $check_stmt->bind_param("ii", $id, $userid);
                                    $check_stmt->execute();
                                    $existing_booking = $check_stmt->get_result();

                                    // Check for time clashes
                                    $check_clash_sql = "SELECT a.* FROM appointment a 
                                                       INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
                                                       WHERE a.pid=? AND s.scheduledate=? AND s.scheduletime=? AND a.status != 'cancelled'";
                                    $clash_stmt = $database->prepare($check_clash_sql);
                                    $clash_stmt->bind_param("iss", $userid, $sheduledate, $scheduletime);
                                    $clash_stmt->execute();
                                    $time_clash = $clash_stmt->get_result();

                                    // Check for same day appointments
                                    $check_same_day_sql = "SELECT a.* FROM appointment a 
                                                          INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
                                                          WHERE a.pid=? AND s.scheduledate=? AND a.status != 'cancelled'";
                                    $day_stmt = $database->prepare($check_same_day_sql);
                                    $day_stmt->bind_param("is", $userid, $sheduledate);
                                    $day_stmt->execute();
                                    $same_day = $day_stmt->get_result();

                                    $can_book = true;
                                    $error_type = '';

                                    if($existing_booking->num_rows > 0) {
                                        $can_book = false;
                                        $error_type = 'multiple_booking';
                                    } elseif($time_clash->num_rows > 0) {
                                        $can_book = false;
                                        $error_type = 'timeclash';
                                    } elseif($same_day->num_rows > 0) {
                                        $can_book = false;
                                        $error_type = 'sameday';
                                    } elseif($booked_count >= $nop) { // Use the actual nop value from schedule
                                        $can_book = false;
                                        $error_type = 'slotfull';
                                    }
                                    
                                    // Determine capacity status
                                    $capacity_class = 'capacity-info';
                                    $capacity_message = "Available: " . ($nop - $booked_count) . " slots remaining";
                                    
                                    if ($booked_count >= $nop) {
                                        $capacity_class = 'capacity-full';
                                        $capacity_message = "FULLY BOOKED";
                                    } elseif ($booked_count >= ($nop * 0.8)) {
                                        $capacity_class = 'capacity-warning';
                                        $capacity_message = "Almost Full: " . ($nop - $booked_count) . " slots left";
                                    }
                                    
                                    if($can_book) {
                                        echo '
                                            <form action="booking-complete.php" method="post">
                                                <input type="hidden" name="scheduleid" value="'.$scheduleid.'" >
                                                <input type="hidden" name="apponum" value="'.$apponum.'" >
                                                <input type="hidden" name="date" value="'.$today.'" >
                                                <input type="hidden" name="scheduledate" value="'.$sheduledate.'" >
                                                <input type="hidden" name="scheduletime" value="'.$scheduletime.'" >
                                        ';
                                    } else {
                                        echo '<div class="error-message">';
                                        switch($error_type) {
                                            case 'multiple_booking':
                                                echo 'You have already booked this appointment slot!';
                                                break;
                                            case 'timeclash':
                                                echo 'You already have an appointment at '.$scheduletime.' on '.$sheduledate.'!';
                                                break;
                                            case 'sameday':
                                                echo 'You already have an appointment on '.$sheduledate.'! Please choose another date.';
                                                break;
                                            case 'slotfull':
                                                echo 'This appointment slot is full! Maximum capacity ('.$nop.') reached.';
                                                break;
                                        }
                                        echo '<br><a href="schedule.php"><button class="login-btn btn-primary-soft btn" style="margin-top:10px;">Back to Available Sessions</button></a></div>';
                                    }

                                    echo '
                                    <td style="width: 50%;" rowspan="2">
                                            <div  class="dashboard-items search-items"  >
                                            
                                                <div style="width:100%">
                                                        <div class="h1-search" style="font-size:25px;">
                                                            Session Details
                                                        </div><br><br>
                                                        <div class="h3-search" style="font-size:18px;line-height:30px">
                                                            Doctor name:  &nbsp;&nbsp;<b>'.$docname.'</b><br>
                                                            Doctor Email:  &nbsp;&nbsp;<b>'.$docemail.'</b> 
                                                        </div>
                                                        <div class="h3-search" style="font-size:18px;">
                                                          
                                                        </div><br>
                                                        <div class="h3-search" style="font-size:18px;">
                                                            Session Title: '.$title.'<br>
                                                            Session Scheduled Date: '.$sheduledate.'<br>
                                                            Session Starts : '.$scheduletime.'<br>
                                                            Maximum Capacity: <b>'.$nop.' patients</b><br>
                                                            Consultation Fee : <b>RM 150.00</b>
                                                        </div>
                                                        <br>
                                                        <div class="'.$capacity_class.'">
                                                            '.$capacity_message.' (Currently: '.$booked_count.'/'.$nop.' booked)
                                                        </div>
                                                </div>
                                                        
                                            </div>
                                        </td>
                                        
                                        <td style="width: 25%;">
                                            <div  class="dashboard-items search-items"  >
                                            
                                                <div style="width:100%;padding-top: 15px;padding-bottom: 15px;">
                                                        <div class="h1-search" style="font-size:20px;line-height: 35px;margin-left:8px;text-align:center;">
                                                            Your Appointment Number
                                                        </div>
                                                        <center>
                                                        <div class=" dashboard-icons" style="margin-left: 0px;width:90%;font-size:70px;font-weight:800;text-align:center;color:var(--btnnictext);background-color: var(--btnice)">'.$apponum.'</div>
                                                    </center>
                                                       
                                                        </div><br>
                                                        
                                                        <br>
                                                        <br>
                                                </div>
                                                        
                                            </div>
                                        </td>
                                        </tr>
                                                                                ';
                                        if($can_book) {
                                            echo '
                                        <tr>
                                            <td>
                                                <input type="Submit" class="login-btn btn-primary btn btn-book" style="margin-left:10px;padding-left: 25px;padding-right: 25px;padding-top: 10px;padding-bottom: 10px;width:95%;text-align: center;" value="Book now" name="booknow">
                                            </form>
                                            </td>
                                        </tr>
                                            ';
                                        }
                                        echo '
                                        '; 

                                }

                            }
                            ?>
 
                            </tbody>

                        </table>
                        </div>
                        </center>
                   </td> 
                </tr>
                        
            </table>
        </div>
    </div>
   
    </div>

</body>
</html>