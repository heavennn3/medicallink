<?php
session_start();

if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
        header("location: ../login.php");
    }
}else{
    header("location: ../login.php");
}

require_once '../vendor/autoload.php'; // If using Composer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include("../connection.php");

function sendReceiptWithSMTP($appointment, $to_email, $cc_email = null) {
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // Gmail SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'your-email@gmail.com';  // Your Gmail
        $mail->Password = 'your-app-password';     // Gmail App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        // Recipients
        $mail->setFrom('noreply@medicallink.com', 'Medical Link');
        $mail->addAddress($to_email);
        
        if($cc_email) {
            $mail->addCC($cc_email);
        }
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = "Medical Appointment Receipt - Reference OC-000-" . $appointment['appoid'];
        $mail->Body = generateReceiptHTML($appointment);
        $mail->AltBody = generateReceiptText($appointment);
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email failed: " . $mail->ErrorInfo);
        return false;
    }
}

function generateReceiptHTML($appointment) {
    $receipt_number = "OC-000-" . $appointment['appoid'];
    $appointment_date = date('F j, Y', strtotime($appointment['scheduledate']));
    $appointment_time = date('g:i A', strtotime($appointment['scheduletime']));
    $booking_date = date('F j, Y', strtotime($appointment['appodate']));
    
    return '
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px; }
            .header { text-align: center; background: #007bff; color: white; padding: 20px; border-radius: 10px 10px 0 0; }
            .receipt-details { background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 5px; }
            .detail-row { display: flex; justify-content: space-between; margin-bottom: 10px; }
            .detail-label { font-weight: bold; color: #555; }
            .total-section { background: #e8f5e8; padding: 15px; border-radius: 5px; text-align: center; font-size: 18px; font-weight: bold; }
            .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Medical Link - Appointment Receipt</h1>
                <p>Thank you for choosing our medical services</p>
            </div>
            
            <div class="receipt-details">
                <div class="detail-row">
                    <span class="detail-label">Receipt Number:</span>
                    <span>'.$receipt_number.'</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Booking Date:</span>
                    <span>'.$booking_date.'</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Patient Name:</span>
                    <span>'.$appointment['pname'].'</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Doctor:</span>
                    <span>Dr. '.$appointment['docname'].'</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Session:</span>
                    <span>'.$appointment['title'].'</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Appointment Date:</span>
                    <span>'.$appointment_date.'</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Appointment Time:</span>
                    <span>'.$appointment_time.'</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Appointment Number:</span>
                    <span>'.$appointment['apponum'].'</span>
                </div>
            </div>
            
            <div class="total-section">
                Consultation Fee: RM 150.00
            </div>
            
            <div class="footer">
                <p>This is an automated receipt. Please keep this for your records.</p>
                <p>Medical Link Clinic<br>
                Contact: +603-1234 5678 | Email: info@medicallink.com</p>
            </div>
        </div>
    </body>
    </html>';
}

function generateReceiptText($appointment) {
    $receipt_number = "OC-000-" . $appointment['appoid'];
    
    return "
    MEDICAL LINK - APPOINTMENT RECEIPT
    ==================================
    
    Receipt Number: $receipt_number
    Booking Date: " . date('F j, Y', strtotime($appointment['appodate'])) . "
    Patient Name: " . $appointment['pname'] . "
    Doctor: Dr. " . $appointment['docname'] . "
    Session: " . $appointment['title'] . "
    Appointment Date: " . date('F j, Y', strtotime($appointment['scheduledate'])) . "
    Appointment Time: " . date('g:i A', strtotime($appointment['scheduletime'])) . "
    Appointment Number: " . $appointment['apponum'] . "
    
    Consultation Fee: RM 150.00
    
    Thank you for choosing Medical Link!
    Contact: +603-1234 5678 | Email: info@medicallink.com
    ";
}

// Handle the email sending
if($_POST && isset($_POST['send_receipt'])) {
    $appointment_id = $_POST['appointment_id'];
    $email = $_POST['email'];
    $send_copy = isset($_POST['send_copy']) ? true : false;
    
    // Get appointment details
    $sql = "SELECT a.*, s.title, s.scheduledate, s.scheduletime, d.docname, d.docemail, p.pname, p.pemail 
            FROM appointment a 
            INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
            INNER JOIN doctor d ON s.docid = d.docid 
            INNER JOIN patient p ON a.pid = p.pid 
            WHERE a.appoid = ?";
    $stmt = $database->prepare($sql);
    $stmt->bind_param("i", $appointment_id);
    $stmt->execute();
    $appointment = $stmt->get_result()->fetch_assoc();
    
    if($appointment) {
        // Try SMTP first, fallback to basic mail()
        if(sendReceiptWithSMTP($appointment, $email, $send_copy ? $_SESSION["user"] : null)) {
            header("location: appointment.php?action=receipt-sent&id=".$appointment_id);
        } else {
            // Fallback to basic mail
            $subject = "Medical Appointment Receipt - Reference OC-000-" . $appointment['appoid'];
            $message = generateReceiptHTML($appointment);
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: Medical Link <noreply@medicallink.com>" . "\r\n";
            
            if($send_copy) {
                $headers .= "Cc: " . $_SESSION["user"] . "\r\n";
            }
            
            if(mail($email, $subject, $message, $headers)) {
                header("location: appointment.php?action=receipt-sent&id=".$appointment_id);
            } else {
                header("location: receipt.php?appointment_id=".$appointment_id."&error=email_failed");
            }
        }
    }
}
?>