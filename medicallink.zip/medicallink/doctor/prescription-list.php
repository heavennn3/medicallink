<?php
session_start();

if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='d'){
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
}

include("../connection.php");
$userrow = $database->query("select * from doctor where docemail='$useremail'");
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["docid"];
$username=$userfetch["docname"];

// Get prescriptions for this doctor
$sqlmain= "SELECT p.*, pat.pname, pat.pemail 
           FROM prescriptions p 
           INNER JOIN patient pat ON p.patient_id = pat.pid 
           WHERE p.doctor_id = ? 
           ORDER BY p.prescription_date DESC";
$stmt = $database->prepare($sqlmain);
$stmt->bind_param("i", $userid);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Prescriptions</title>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../css/prescription.css">
</head>
<body>
    <div class="container">
        <div class="menu">
            <!-- Your existing menu code -->
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="../img/user.png" alt="Profile Picture" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title"><?php echo substr($username,0,13); ?>..</p>
                                    <p class="profile-subtitle"><?php echo substr($useremail,0,22); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-dashbord" >
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Appointments</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">My Sessions</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-patient">
                        <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">My Patients</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-prescription menu-active menu-icon-prescription-active">
                        <a href="prescription-list.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Prescriptions</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a>
                    </td>
                </tr>
            </table>
        </div>
        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;" >
                <tr>
                    <td colspan="1" class="nav-bar" >
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;margin-left:20px;">My Prescriptions</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <center>
                            <div class="prescription-container">
                                <?php if ($result->num_rows == 0): ?>
                                    <div style="text-align: center; padding: 40px;">
                                        <img src="../img/notfound.svg" width="25%">
                                        <br>
                                        <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">No prescriptions found!</p>
                                        <p>You haven't created any prescriptions yet.</p>
                                    </div>
                                <?php else: ?>
                                    <?php while ($row = $result->fetch_assoc()): ?>
                                        <div class="prescription-card">
                                            <h4>Prescription #<?php echo $row['prescription_id']; ?></h4>
                                            <div class="prescription-meta">
                                                <span><strong>Patient:</strong> <?php echo $row['pname']; ?></span>
                                                <span><strong>Date:</strong> <?php echo date('F j, Y', strtotime($row['prescription_date'])); ?></span>
                                                <span><strong>Status:</strong> <?php echo ucfirst($row['status']); ?></span>
                                            </div>
                                            <p><strong>Diagnosis:</strong> <?php echo substr($row['diagnosis'], 0, 100); ?>...</p>
                                            <div class="actions">
                                                <a href="prescription-view.php?id=<?php echo $row['prescription_id']; ?>" class="btn-primary">View Details</a>
                                                <a href="prescription-create.php?patient_id=<?php echo $row['patient_id']; ?>" class="btn-secondary">Create New for Same Patient</a>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                <?php endif; ?>
                            </div>
                        </center>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>