<?php
session_start();
if (!isset($_SESSION["user"]) || $_SESSION["usertype"] != "d") {
    header("location: ../login.php");
    exit;
}

include("../connection.php");
$doctor_email = $_SESSION["user"];

// Get doctor info
$doctor_row = $database->query("select * from doctor where docemail='$doctor_email'");
$doctor_fetch = $doctor_row->fetch_assoc();
$doctor_id = $doctor_fetch["docid"];
$doctor_name = $doctor_fetch["docname"];

// Get doctor picture if exists
$doctor_picture = "../img/user.png";
$possible_picture_columns = ['docpicture', 'picture', 'profile_picture', 'doc_profile_picture'];

foreach ($possible_picture_columns as $column) {
    if(isset($doctor_fetch[$column]) && !empty($doctor_fetch[$column])) {
        $picture_path = "../" . $doctor_fetch[$column];
        if (file_exists($picture_path)) {
            $doctor_picture = $picture_path;
        }
        break;
    }
}

// Get appointment ID from URL
$appointment_id = isset($_GET['appointment_id']) ? $_GET['appointment_id'] : '';

// Get doctor's appointments with patients for sidebar
$appointments = $database->query("
    SELECT a.appoid, a.appodate, s.title, p.pname, p.pemail, s.scheduledate, s.scheduletime 
    FROM appointment a 
    INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
    INNER JOIN patient p ON a.pid = p.pid 
    WHERE s.docid = '$doctor_id' 
    ORDER BY s.scheduledate DESC
");

// If specific appointment is selected, verify it belongs to this doctor
if ($appointment_id) {
    $appointment_check = $database->query("
        SELECT a.*, p.pname, p.pemail, s.title, s.scheduledate
        FROM appointment a 
        INNER JOIN schedule s ON a.scheduleid = s.scheduleid 
        INNER JOIN patient p ON a.pid = p.pid 
        WHERE a.appoid = '$appointment_id' 
        AND s.docid = '$doctor_id'
    ");
    
    if ($appointment_check->num_rows == 0) {
        header("location: chat.php");
        exit;
    }
    
    $current_appointment = $appointment_check->fetch_assoc();
    
    // Get chat messages
    $messages_result = $database->query("
        SELECT * FROM chat_message 
        WHERE appointment_id = '$appointment_id' 
        ORDER BY timestamp ASC
    ");
    
    // Mark patient messages as read
    $database->query("
        UPDATE chat_message 
        SET s_read = TRUE 
        WHERE appointment_id = '$appointment_id' 
        AND sender_type = 'patient'
    ");
}

// Handle sending new message
if ($_POST && isset($_POST['send_message']) && $appointment_id) {
    $message = trim($_POST['message']);
    if (!empty($message)) {
        $database->query("
            INSERT INTO chat_message (appointment_id, sender_type, sender_email, message) 
            VALUES ('$appointment_id', 'doctor', '$doctor_email', '" . $database->real_escape_string($message) . "')
        ");
        header("location: chat.php?appointment_id=" . $appointment_id);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat with Patients</title>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .chat-container {
            display: flex;
            height: 70vh;
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            margin: 20px;
        }
        
        .appointments-sidebar {
            width: 350px;
            border-right: 1px solid #ddd;
            background: #f8f9fa;
            overflow-y: auto;
        }
        
        .chat-area {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .chat-header {
            padding: 15px;
            background: #28a745;
            color: white;
            border-bottom: 1px solid #ddd;
        }
        
        .messages-container {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f0f2f5;
        }
        
        .message {
            margin-bottom: 15px;
            padding: 12px 16px;
            border-radius: 18px;
            max-width: 70%;
            word-wrap: break-word;
            position: relative;
        }
        
        .doctor-message {
            background: #28a745;
            color: white;
            margin-left: auto;
            border-bottom-right-radius: 5px;
        }
        
        .patient-message {
            background: white;
            color: #333;
            border: 1px solid #ddd;
            border-bottom-left-radius: 5px;
        }
        
        .message-sender {
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .message-time {
            font-size: 11px;
            opacity: 0.7;
            text-align: right;
            margin-top: 5px;
        }
        
        .chat-input {
            padding: 15px;
            border-top: 1px solid #ddd;
            background: white;
        }
        
        .message-form {
            display: flex;
            gap: 10px;
        }
        
        .message-input {
            flex: 1;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 25px;
            outline: none;
        }
        
        .send-btn {
            padding: 12px 25px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
        }
        
        .send-btn:hover {
            background: #218838;
        }
        
        .appointment-item {
            padding: 15px;
            border-bottom: 1px solid #ddd;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .appointment-item:hover {
            background: #e9ecef;
        }
        
        .appointment-item.active {
            background: #28a745;
            color: white;
        }
        
        .no-chat-selected {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: #6c757d;
            text-align: center;
        }
        
        .unread-badge {
            background: #dc3545;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            margin-left: 10px;
        }
        
        .empty-chat {
            text-align: center;
            color: #6c757d;
            padding: 40px;
        }
        
        .patient-info {
            font-size: 12px;
            opacity: 0.8;
            margin-top: 5px;
        }
        
        .refresh-btn {
            padding: 8px 15px;
            background: #17a2b8;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            margin-left: 10px;
        }
        
        .refresh-btn:hover {
            background: #138496;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="<?php echo $doctor_picture; ?>" alt="Profile Picture" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title"><?php echo substr($doctor_name,0,13); ?>..</p>
                                    <p class="profile-subtitle"><?php echo substr($doctor_email,0,22); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-dashbord" >
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Appointments</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">My Sessions</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-patient">
                        <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">My Patients</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-chat menu-active menu-icon-chat-active">
                        <a href="chat.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Messages</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a>
                    </td>
                </tr>
            </table>
        </div>

        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
                <tr >
                    <td width="13%" >
                    <a href="schedule.php" ><button  class="login-btn btn-primary-soft btn btn-icon-back"  style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                    </td>
                    <td>
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;">Chat with Patients</p>
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 
                                date_default_timezone_set('Asia/Kuala_Lumpur');
                                $today = date('Y-m-d');
                                echo $today;
                            ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button  class="btn-label"  style="display: flex;justify-content: center;align-items: center;"><img src="../img/calendar.svg" width="100%"></button>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="4">
                        <div class="chat-container">
                            <!-- Appointments Sidebar -->
                            <div class="appointments-sidebar">
                                <div style="padding: 15px; border-bottom: 1px solid #ddd; background: #28a745; color: white; display: flex; justify-content: space-between; align-items: center;">
                                    <strong>Upcoming Appointments</strong>
                                    <button class="refresh-btn" onclick="location.reload()" title="Refresh">
                                        ↻
                                    </button>
                                </div>
                                <?php while($appointment = $appointments->fetch_assoc()): 
                                    // Check for unread messages
                                    $unread_count = $database->query("
                                        SELECT COUNT(*) as count FROM chat_message 
                                        WHERE appointment_id = '{$appointment['appoid']}' 
                                        AND sender_type = 'patient' 
                                        AND s_read = FALSE
                                    ")->fetch_assoc()['count'];
                                ?>
                                    <div class="appointment-item <?php echo $appointment_id == $appointment['appoid'] ? 'active' : ''; ?>" 
                                         onclick="location.href='chat.php?appointment_id=<?php echo $appointment['appoid']; ?>'">
                                        <div><strong><?php echo $appointment['pname']; ?></strong></div>
                                        <div class="patient-info">
                                            Session: <?php echo $appointment['title']; ?>
                                        </div>
                                        <div style="font-size: 12px; margin-top: 5px;">
                                            <?php echo $appointment['scheduledate']; ?> at <?php echo $appointment['scheduletime']; ?>
                                        </div>
                                        <?php if ($unread_count > 0): ?>
                                            <span class="unread-badge"><?php echo $unread_count; ?></span>
                                        <?php endif; ?>
                                    </div>
                                <?php endwhile; ?>
                                
                                <?php if($appointments->num_rows == 0): ?>
                                    <div style="padding: 20px; text-align: center; color: #6c757d;">
                                        No appointments found
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Chat Area -->
                            <div class="chat-area">
                                <?php if($appointment_id): ?>
                                    <div class="chat-header" style="display: flex; justify-content: space-between; align-items: center;">
                                        <div>
                                            <strong>Chat with <?php echo $current_appointment['pname']; ?></strong>
                                            <div style="font-size: 12px;">
                                                Session: <?php echo $current_appointment['title']; ?> | 
                                                Date: <?php echo isset($current_appointment['scheduledate']) ? $current_appointment['scheduledate'] : 'Not scheduled'; ?>
                                            </div>
                                        </div>
                                        <button class="refresh-btn" onclick="location.reload()" title="Refresh Messages">
                                            ↻ Refresh
                                        </button>
                                    </div>
                                    
                                    <div class="messages-container" id="messagesContainer">
                                        <?php if($messages_result->num_rows > 0): ?>
                                            <?php while($message = $messages_result->fetch_assoc()): ?>
                                                <div class="message <?php echo $message['sender_type'] == 'doctor' ? 'doctor-message' : 'patient-message'; ?>">
                                                    <div class="message-sender">
                                                        <?php echo $message['sender_type'] == 'doctor' ? 'You' : $current_appointment['pname']; ?>
                                                    </div>
                                                    <?php echo htmlspecialchars($message['message']); ?>
                                                    <div class="message-time">
                                                        <?php echo date('M j, g:i A', strtotime($message['timestamp'])); ?>
                                                    </div>
                                                </div>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <div class="empty-chat">
                                                <p>No messages yet. Start the conversation!</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="chat-input">
                                        <form method="POST" class="message-form" id="messageForm">
                                            <input type="text" name="message" class="message-input" placeholder="Type your message..." required>
                                            <button type="submit" name="send_message" class="send-btn">Send</button>
                                        </form>
                                    </div>
                                <?php else: ?>
                                    <div class="no-chat-selected">
                                        <div>
                                            <p style="font-size: 18px; margin-bottom: 10px;">Select a patient to start chatting</p>
                                            <p style="color: #6c757d;">Choose one of your upcoming appointments from the sidebar</p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <script>
        // Auto-scroll to bottom of messages
        function scrollToBottom() {
            const container = document.getElementById('messagesContainer');
            if (container) {
                container.scrollTop = container.scrollHeight;
            }
        }
        
        // Scroll to bottom when page loads
        window.onload = scrollToBottom;
        
        // Scroll to bottom when sending a message
        document.addEventListener('DOMContentLoaded', function() {
            const messageForm = document.getElementById('messageForm');
            if (messageForm) {
                messageForm.addEventListener('submit', function() {
                    setTimeout(scrollToBottom, 100);
                });
            }
        });
        
        // Optional: Manual refresh button instead of auto-refresh
        // You can remove the auto-refresh interval completely
    </script>
</body>
</html>