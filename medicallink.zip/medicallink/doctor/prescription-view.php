<?php
session_start();

if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='d'){
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
}

include("../connection.php");

// Get doctor info
$userrow = $database->query("select * from doctor where docemail='$useremail'");
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["docid"];
$username=$userfetch["docname"];

// Get prescription details
if(isset($_GET['id'])) {
    $prescription_id = $_GET['id'];
    
    // First, let's check if the prescriptions table exists and what columns it has
    $table_check = $database->query("SHOW TABLES LIKE 'prescriptions'");
    if($table_check->num_rows == 0) {
        // Table doesn't exist, redirect back
        header("location: prescription-list.php");
        exit();
    }
    
    // Simple query first to avoid prepare errors
    $sql = "SELECT p.*, pat.pname, pat.pemail, pat.pnic, pat.ptel, pat.pdob, pat.paddress, 
                   doc.docname as doctor_name
            FROM prescriptions p 
            INNER JOIN patient pat ON p.patient_id = pat.pid 
            INNER JOIN doctor doc ON p.doctor_id = doc.docid
            WHERE p.prescription_id = ? AND p.doctor_id = ?";
    
    $stmt = $database->prepare($sql);
    if($stmt === false) {
        // If prepare fails, try a simpler query
        $sql = "SELECT p.*, pat.pname, pat.pemail 
                FROM prescriptions p 
                INNER JOIN patient pat ON p.patient_id = pat.pid 
                WHERE p.prescription_id = ? AND p.doctor_id = ?";
        $stmt = $database->prepare($sql);
    }
    
    if($stmt !== false) {
        $stmt->bind_param("ii", $prescription_id, $userid);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if($result->num_rows == 0) {
            header("location: prescription-list.php");
            exit();
        }
        
        $prescription = $result->fetch_assoc();
    } else {
        // If all prepares fail, redirect back
        header("location: prescription-list.php");
        exit();
    }
} else {
    header("location: prescription-list.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Prescription</title>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .prescription-view {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin: 20px;
            max-width: 900px;
        }
        .prescription-header {
            text-align: center;
            border-bottom: 2px solid #007bff;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .prescription-section {
            margin-bottom: 30px;
        }
        .prescription-section h3 {
            color: #007bff;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .medicine-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 10px;
            border-left: 4px solid #007bff;
        }
        .signature-area {
            margin-top: 50px;
            text-align: right;
            border-top: 1px solid #ddd;
            padding-top: 20px;
        }
        .btn-print {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        .info-table {
            width: 100%;
            border-collapse: collapse;
        }
        .info-table td {
            padding: 8px;
            border-bottom: 1px solid #f0f0f0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="../img/user.png" alt="Profile Picture" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title"><?php echo substr($username,0,13); ?>..</p>
                                    <p class="profile-subtitle"><?php echo substr($useremail,0,22); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-dashbord" >
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Appointments</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">My Sessions</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-patient">
                        <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">My Patients</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-prescription menu-active menu-icon-prescription-active">
                        <a href="prescription-list.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Prescriptions</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a>
                    </td>
                </tr>
            </table>
        </div>
        <div class="dash-body">
            <table border="0" width="100%" style="border-spacing: 0;margin:0;padding:0;">
                <tr>
                    <td colspan="1" class="nav-bar">
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;margin-left:20px;">
                            <a href="prescription-list.php" style="text-decoration: none; color: inherit;">← Back to Prescriptions</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <center>
                            <div class="prescription-view">
                                <button class="btn-print" onclick="window.print()">🖨️ Print Prescription</button>
                                
                                <div class="prescription-header">
                                    <h1>MEDICAL PRESCRIPTION</h1>
                                    <p>Prescription #<?php echo $prescription['prescription_id']; ?></p>
                                </div>
                                
                                <div class="prescription-section">
                                    <h3>Patient Information</h3>
                                    <table class="info-table">
                                        <tr>
                                            <td width="50%"><strong>Name:</strong> <?php echo $prescription['pname']; ?></td>
                                            <td><strong>NIC:</strong> <?php echo isset($prescription['pnic']) ? $prescription['pnic'] : 'N/A'; ?></td>
                                        </tr>
                                        <tr>
                                            <td><strong>Email:</strong> <?php echo $prescription['pemail']; ?></td>
                                            <td><strong>Phone:</strong> <?php echo isset($prescription['ptel']) ? $prescription['ptel'] : 'N/A'; ?></td>
                                        </tr>
                                        <tr>
                                            <td><strong>Date of Birth:</strong> <?php echo isset($prescription['pdob']) ? $prescription['pdob'] : 'N/A'; ?></td>
                                            <td><strong>Address:</strong> <?php echo isset($prescription['paddress']) ? $prescription['paddress'] : 'N/A'; ?></td>
                                        </tr>
                                    </table>
                                </div>
                                
                                <div class="prescription-section">
                                    <h3>Medical Information</h3>
                                    <p><strong>Diagnosis:</strong> <?php echo isset($prescription['diagnosis']) ? $prescription['diagnosis'] : 'Not specified'; ?></p>
                                    <p><strong>Symptoms:</strong> <?php echo isset($prescription['symptoms']) ? $prescription['symptoms'] : 'Not specified'; ?></p>
                                    <p><strong>Notes:</strong> <?php echo isset($prescription['notes']) ? $prescription['notes'] : 'No additional notes'; ?></p>
                                </div>
                                
                                <div class="prescription-section">
                                    <h3>Medications</h3>
                                    <?php 
                                    if(isset($prescription['medicines']) && !empty($prescription['medicines'])) {
                                        $medicines = json_decode($prescription['medicines'], true);
                                        if(is_array($medicines) && count($medicines) > 0): 
                                            foreach($medicines as $medicine): ?>
                                                <div class="medicine-item">
                                                    <strong><?php echo $medicine['name']; ?></strong><br>
                                                    Dosage: <?php echo $medicine['dosage']; ?><br>
                                                    Frequency: <?php echo $medicine['frequency']; ?><br>
                                                    Duration: <?php echo $medicine['duration']; ?><br>
                                                    Instructions: <?php echo $medicine['instructions']; ?>
                                                </div>
                                            <?php endforeach; 
                                        else: ?>
                                            <p>No medications prescribed.</p>
                                        <?php endif;
                                    } else {
                                        echo '<p>No medications prescribed.</p>';
                                    }
                                    ?>
                                </div>
                                
                                <div class="prescription-section">
                                    <h3>Doctor Information</h3>
                                    <p><strong>Doctor:</strong> <?php echo isset($prescription['doctor_name']) ? $prescription['doctor_name'] : $username; ?></p>
                                    <p><strong>Date:</strong> <?php echo date('F j, Y', strtotime($prescription['prescription_date'])); ?></p>
                                </div>
                                
                                <div class="signature-area">
                                    <p><strong>Signature:</strong> _________________________</p>
                                    <p><strong>Doctor:</strong> <?php echo $username; ?></p>
                                </div>
                            </div>
                        </center>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>