<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='d'){
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
}

include("../connection.php");
$userrow = $database->query("select * from doctor where docemail='$useremail'");
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["docid"];
$username=$userfetch["docname"];

$patient_id = $_GET['patient_id'] ?? '';
$appointment_id = $_GET['appointment_id'] ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patient_id = $_POST['patient_id'];
    $appointment_id = $_POST['appointment_id'] ?? null;
    $diagnosis = $_POST['diagnosis'];
    $notes = $_POST['notes'];
    
    // Insert prescription
    $stmt = $database->prepare("INSERT INTO prescriptions (patient_id, doctor_id, appointment_id, diagnosis, notes) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iiiss", $patient_id, $userid, $appointment_id, $diagnosis, $notes);
    
    if ($stmt->execute()) {
        $prescription_id = $stmt->insert_id;
        
        // Insert prescription items
        $medicines = $_POST['medicine_name'];
        $dosages = $_POST['dosage'];
        $frequencies = $_POST['frequency'];
        $durations = $_POST['duration'];
        $instructions = $_POST['instructions'];
        
        $item_stmt = $database->prepare("INSERT INTO prescription_items (prescription_id, medicine_name, dosage, frequency, duration, instructions) VALUES (?, ?, ?, ?, ?, ?)");
        
        for ($i = 0; $i < count($medicines); $i++) {
            if (!empty($medicines[$i])) {
                $item_stmt->bind_param("isssss", $prescription_id, $medicines[$i], $dosages[$i], $frequencies[$i], $durations[$i], $instructions[$i]);
                $item_stmt->execute();
            }
        }
        
        $_SESSION['success'] = "Prescription created successfully!";
        header("Location: appointment.php");
        exit();
    } else {
        $error = "Error creating prescription: " . $database->error;
    }
}

// Get patient details if patient_id is provided
$patient = null;
if ($patient_id) {
    $stmt = $database->prepare("SELECT * FROM patient WHERE pid = ?");
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    $patient = $stmt->get_result()->fetch_assoc();
}

// Get appointment details if appointment_id is provided
$appointment = null;
if ($appointment_id) {
    $stmt = $database->prepare("SELECT appointment.*, schedule.scheduledate, schedule.scheduletime FROM appointment INNER JOIN schedule ON appointment.scheduleid=schedule.scheduleid WHERE appointment.appoid = ?");
    $stmt->bind_param("i", $appointment_id);
    $stmt->execute();
    $appointment = $stmt->get_result()->fetch_assoc();
}

// Get doctor picture if exists
$doctor_picture = "../img/user.png";
$possible_picture_columns = ['docpicture', 'picture', 'profile_picture', 'doc_profile_picture'];

foreach ($possible_picture_columns as $column) {
    if(isset($userfetch[$column]) && !empty($userfetch[$column])) {
        $picture_path = "../" . $userfetch[$column];
        if (file_exists($picture_path)) {
            $doctor_picture = $picture_path;
        }
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Prescription</title>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .prescription-container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .prescription-header {
            border-bottom: 2px solid #007bff;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .form-row {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr 2fr;
            gap: 10px;
            margin-bottom: 10px;
            align-items: start;
        }
        .medicine-item {
            padding: 15px;
            border: 1px solid #eee;
            border-radius: 5px;
            margin-bottom: 10px;
            background: #f9f9f9;
        }
        .btn-primary {
            background: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .add-medicine {
            background: #28a745;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        .actions {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }
        .patient-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="<?php echo $doctor_picture; ?>" alt="Profile Picture" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title"><?php echo substr($username,0,13); ?>..</p>
                                    <p class="profile-subtitle"><?php echo substr($useremail,0,22); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-dashbord" >
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Appointments</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">My Sessions</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-patient">
                        <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">My Patients</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-prescription menu-active menu-icon-prescription-active">
                        <a href="prescription-list.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Prescriptions</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a>
                    </td>
                </tr>
            </table>
        </div>
        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;" >
                <tr>
                    <td colspan="1" class="nav-bar" >
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;margin-left:20px;">Create Prescription</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <center>
                            <div class="prescription-container">
                                <?php if (isset($error)): ?>
                                    <div class="error-message" style="color: red; margin-bottom: 15px; padding: 10px; background: #f8d7da; border-radius: 5px;"><?php echo $error; ?></div>
                                <?php endif; ?>
                                
                                <?php if ($patient): ?>
                                <div class="patient-info">
                                    <h3>Patient Information</h3>
                                    <p><strong>Name:</strong> <?php echo $patient['pname']; ?></p>
                                    <p><strong>Email:</strong> <?php echo $patient['pemail']; ?></p>
                                    <?php if ($appointment): ?>
                                        <p><strong>Appointment Date:</strong> <?php echo $appointment['scheduledate']; ?> <?php echo $appointment['scheduletime']; ?></p>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                                
                                <form method="POST">
                                    <input type="hidden" name="patient_id" value="<?php echo $patient_id; ?>">
                                    <input type="hidden" name="appointment_id" value="<?php echo $appointment_id; ?>">
                                    
                                    <div class="form-group">
                                        <label>Diagnosis:</label>
                                        <textarea name="diagnosis" rows="3" required placeholder="Enter diagnosis details..."></textarea>
                                    </div>
                                    
                                    <div class="medicines-container">
                                        <h3>Medicines</h3>
                                        <div class="medicine-item">
                                            <div class="form-row">
                                                <input type="text" name="medicine_name[]" placeholder="Medicine Name" required>
                                                <input type="text" name="dosage[]" placeholder="Dosage (e.g., 500mg)">
                                                <input type="text" name="frequency[]" placeholder="Frequency (e.g., 2 times daily)">
                                                <input type="text" name="duration[]" placeholder="Duration (e.g., 7 days)">
                                                <textarea name="instructions[]" placeholder="Special Instructions"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <button type="button" class="add-medicine">Add Another Medicine</button>
                                    
                                    <div class="form-group">
                                        <label>Additional Notes:</label>
                                        <textarea name="notes" rows="3" placeholder="Any additional notes or instructions..."></textarea>
                                    </div>
                                    
                                    <div class="actions">
                                        <button type="submit" class="btn-primary">Create Prescription</button>
                                        <a href="appointment.php" class="btn-secondary">Cancel</a>
                                    </div>
                                </form>
                            </div>
                        </center>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <script>
        document.querySelector('.add-medicine').addEventListener('click', function() {
            const container = document.querySelector('.medicines-container');
            const newItem = document.querySelector('.medicine-item').cloneNode(true);
            
            // Clear input values
            newItem.querySelectorAll('input, textarea').forEach(input => {
                input.value = '';
            });
            
            container.appendChild(newItem);
        });
    </script>
</body>
</html>