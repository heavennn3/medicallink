<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/animations.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/admin.css">
    <title>Add Prescription</title>
    <style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
    </style>
</head>
<body>
<?php
session_start();

if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='d'){
        header("location: ../login.php");
        exit();
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
    exit();
}

include("../connection.php");
$userrow = $database->query("select * from doctor where docemail='$useremail'");
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["docid"];
$username=$userfetch["docname"];

$doctor_picture = "../img/user.png";
$possible_picture_columns = ['docpicture', 'picture', 'profile_picture', 'doc_profile_picture'];

foreach ($possible_picture_columns as $column) {
    if(isset($userfetch[$column]) && !empty($userfetch[$column])) {
        $picture_path = "../" . $userfetch[$column];
        if (file_exists($picture_path)) {
            $doctor_picture = $picture_path;
        }
        break;
    }
}

$error = "";

if($_SERVER["REQUEST_METHOD"] === "POST"){
    $appoid = isset($_POST["appoid"]) ? intval($_POST["appoid"]) : 0;
    $pid = isset($_POST["pid"]) ? intval($_POST["pid"]) : 0;
    $medicine = isset($_POST["medicine"]) ? trim($_POST["medicine"]) : "";
    $dosage = isset($_POST["dosage"]) ? trim($_POST["dosage"]) : "";
    $instructions = isset($_POST["instructions"]) ? trim($_POST["instructions"]) : "";
    $notes = isset($_POST["notes"]) ? trim($_POST["notes"]) : "";

    if($appoid <= 0 || $pid <= 0){
        $error = "Invalid appointment or patient.";
    }elseif($medicine == "" || $dosage == ""){
        $error = "Please fill in both medicine and dosage.";
    }else{
        $today = date('Y-m-d');
        $stmt = $database->prepare("INSERT INTO prescription(appoid,pid,docid,date,medicine,dosage,instructions,notes) VALUES (?,?,?,?,?,?,?,?)");
        if($stmt){
            $stmt->bind_param("iiisssss", $appoid, $pid, $userid, $today, $medicine, $dosage, $instructions, $notes);
            if($stmt->execute()){
                header("Location: appointment.php?prescription=success");
                exit();
            }else{
                $error = "Failed to save prescription.";
            }
            $stmt->close();
        }else{
            $error = "Database error while preparing statement.";
        }
    }
}

$appoid_param = 0;
if(isset($_GET["appoid"])){
    $appoid_param = intval($_GET["appoid"]);
} elseif(isset($appoid)) {
    $appoid_param = intval($appoid);
}

if($appoid_param <= 0){
    echo "<p style='padding:20px;text-align:center;color:red;'>Invalid appointment.</p>";
    exit();
}

$appointment = null;
$appointment_stmt = $database->prepare("SELECT appointment.appoid, appointment.pid, patient.pname, patient.pemail, schedule.scheduledate, schedule.scheduletime
    FROM schedule
    INNER JOIN appointment ON schedule.scheduleid=appointment.scheduleid
    INNER JOIN patient ON patient.pid=appointment.pid
    INNER JOIN doctor ON schedule.docid=doctor.docid
    WHERE appointment.appoid=? AND doctor.docid=?");
if($appointment_stmt){
    $appointment_stmt->bind_param("ii", $appoid_param, $userid);
    $appointment_stmt->execute();
    $appointment_result = $appointment_stmt->get_result();
    if($appointment_result->num_rows > 0){
        $appointment = $appointment_result->fetch_assoc();
    }
    $appointment_stmt->close();
}

if(!$appointment){
    echo "<p style='padding:20px;text-align:center;color:red;'>Appointment not found or you do not have access.</p>";
    exit();
}

$pid_for_prescription = intval($appointment['pid']);

$existing_prescriptions = [];
$pres_stmt = $database->prepare("SELECT id, date, medicine, dosage, instructions, notes FROM prescription WHERE appoid=? AND docid=? ORDER BY date DESC, id DESC");
if($pres_stmt){
    $pres_stmt->bind_param("ii", $appoid_param, $userid);
    $pres_stmt->execute();
    $pres_result = $pres_stmt->get_result();
    while($row = $pres_result->fetch_assoc()){
        $existing_prescriptions[] = $row;
    }
    $pres_stmt->close();
}
?>
<div class="container">
    <div class="menu">
        <table class="menu-container" border="0">
            <tr>
                <td style="padding:10px" colspan="2">
                    <table border="0" class="profile-container">
                        <tr>
                            <td width="30%" style="padding-left:20px">
                                <img src="<?php echo $doctor_picture; ?>" alt="Profile Picture" width="100%" style="border-radius:50%">
                            </td>
                            <td style="padding:0px;margin:0px;">
                                <p class="profile-title"><?php echo substr($username,0,13); ?>..</p>
                                <p class="profile-subtitle"><?php echo substr($useremail,0,22); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-dashbord">
                    <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></div></a>
                </td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-appoinment menu-active menu-icon-appoinment-active">
                    <a href="appointment.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">My Appointments</p></div></a>
                </td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-session">
                    <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">My Sessions</p></div></a>
                </td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-patient">
                    <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">My Patients</p></div></a>
                </td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-settings">
                    <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a>
                </td>
            </tr>
        </table>
    </div>
    <div class="dash-body">
        <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
            <tr>
                <td width="13%">
                    <a href="appointment.php"><button class="login-btn btn-primary-soft btn btn-icon-back" style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                </td>
                <td>
                    <p style="font-size: 23px;padding-left:12px;font-weight: 600;">Add Prescription</p>
                </td>
                <td width="15%">
                    <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                        Today's Date
                    </p>
                    <p class="heading-sub12" style="padding: 0;margin: 0;">
                        <?php
                            date_default_timezone_set('Asia/Kuala_Lumpur');
                            $today = date('Y-m-d');
                            echo $today;
                        ?>
                    </p>
                </td>
                <td width="10%">
                    <button class="btn-label" style="display: flex;justify-content: center;align-items: center;"><img src="../img/calendar.svg" width="100%"></button>
                </td>
            </tr>
            <tr>
                <td colspan="4" style="padding-top:10px;width: 100%;">
                    <center>
                        <table width="80%" class="sub-table scrolldown add-doc-form-container" border="0">
                            <tr>
                                <td>
                                    <p style="padding: 0;margin: 0;text-align: left;font-size: 20px;font-weight: 500;">Patient & Appointment Details</p><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label class="form-label">Patient Name: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <?php echo htmlspecialchars($appointment['pname']); ?><br><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label class="form-label">Patient Email: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <?php echo htmlspecialchars($appointment['pemail']); ?><br><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label class="form-label">Session Date & Time: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <?php echo htmlspecialchars($appointment['scheduledate']); ?> @ <?php echo substr($appointment['scheduletime'],0,5); ?><br><br>
                                </td>
                            </tr>
                        </table>
                    </center>
                </td>
            </tr>
            <tr>
                <td colspan="4" style="padding-top:10px;width: 100%;">
                    <center>
                        <table width="80%" class="sub-table scrolldown add-doc-form-container" border="0">
                            <tr>
                                <td>
                                    <p style="padding: 0;margin: 0;text-align: left;font-size: 20px;font-weight: 500;">Prescription Details</p><br>
                                </td>
                            </tr>
                            <?php if($error != ""){ ?>
                            <tr>
                                <td colspan="2">
                                    <p class="heading-sub12" style="color:rgb(255, 62, 62);text-align:center;">
                                        <?php echo htmlspecialchars($error); ?>
                                    </p>
                                </td>
                            </tr>
                            <?php } ?>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <form action="" method="post" class="add-new-form">
                                        <input type="hidden" name="appoid" value="<?php echo $appointment['appoid']; ?>">
                                        <input type="hidden" name="pid" value="<?php echo $pid_for_prescription; ?>">
                                        <label for="medicine" class="form-label">Medicine(s) <span style="color:red;">*</span></label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <textarea name="medicine" id="medicine" class="input-text" placeholder="Enter medicine name(s)" rows="3" style="height:auto;" required></textarea><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="dosage" class="form-label">Dosage <span style="color:red;">*</span></label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <textarea name="dosage" id="dosage" class="input-text" placeholder="e.g. 1 tablet, 3 times a day" rows="2" style="height:auto;" required></textarea><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="instructions" class="form-label">Instructions</label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <textarea name="instructions" id="instructions" class="input-text" placeholder="e.g. After meals, morning and night" rows="2" style="height:auto;"></textarea><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="notes" class="form-label">Additional Notes</label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <textarea name="notes" id="notes" class="input-text" placeholder="Optional notes" rows="2" style="height:auto;"></textarea><br>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <input type="reset" value="Reset" class="login-btn btn-primary-soft btn">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="submit" value="Save Prescription" class="login-btn btn-primary btn">
                                </td>
                            </tr>
                            </form>
                        </table>
                    </center>
                </td>
            </tr>
            <?php if(count($existing_prescriptions) > 0){ ?>
            <tr>
                <td colspan="4" style="padding-top:10px;width: 100%;">
                    <center>
                        <table width="80%" class="sub-table scrolldown" border="0">
                            <thead>
                                <tr>
                                    <th class="table-headin">Date</th>
                                    <th class="table-headin">Medicine</th>
                                    <th class="table-headin">Dosage</th>
                                    <th class="table-headin">Instructions</th>
                                    <th class="table-headin">Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($existing_prescriptions as $p){ ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($p['date']); ?></td>
                                        <td><?php echo nl2br(htmlspecialchars($p['medicine'])); ?></td>
                                        <td><?php echo nl2br(htmlspecialchars($p['dosage'])); ?></td>
                                        <td><?php echo nl2br(htmlspecialchars($p['instructions'])); ?></td>
                                        <td><?php echo nl2br(htmlspecialchars($p['notes'])); ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </center>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>
</body>
</html>
