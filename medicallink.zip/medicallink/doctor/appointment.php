<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
        
    <title>Appointments</title>
    <style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .status-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-scheduled { background: #e3f2fd; color: #1976d2; }
        .status-completed { background: #e8f5e8; color: #2e7d32; }
        .status-cancelled { background: #ffebee; color: #c62828; }
        .status-rescheduled { background: #fff3e0; color: #ef6c00; }
        .capacity-info {
            font-size: 11px;
            color: #666;
            background: #f8f9fa;
            padding: 2px 6px;
            border-radius: 8px;
            margin-top: 4px;
        }
        .capacity-full {
            background: #ffebee;
            color: #c62828;
        }
        .capacity-warning {
            background: #fff3e0;
            color: #ef6c00;
        }
        .popup {
            max-width: 95%;
            max-height: 90vh;
            overflow-y: auto;
        }
        .sub-table.scrolldown {
            width: 100%;
        }
        .add-doc-form-container {
            width: 100% !important;
        }
    </style>
</head>
<body>
    <?php
    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='d'){
            header("location: ../login.php");
        }else{
            $useremail=$_SESSION["user"];
        }
    }else{
        header("location: ../login.php");
    }

    include("../connection.php");
    $userrow = $database->query("select * from doctor where docemail='$useremail'");
    $userfetch=$userrow->fetch_assoc();
    $userid= $userfetch["docid"];
    $username=$userfetch["docname"];
    

    if($_POST && isset($_POST['update_status'])){
        $appoid = $_POST['appoid'];
        $status = $_POST['status'];
        

        $rescheduled_date = (!empty($_POST['rescheduled_date']) && $_POST['rescheduled_date'] != '') ? $_POST['rescheduled_date'] : null;
        $rescheduled_time = (!empty($_POST['rescheduled_time']) && $_POST['rescheduled_time'] != '') ? $_POST['rescheduled_time'] : null;
        $cancellation_reason = (!empty($_POST['cancellation_reason'])) ? $_POST['cancellation_reason'] : null;
        

        if ($status != 'rescheduled') {
            $rescheduled_date = null;
            $rescheduled_time = null;
        }
        if ($status != 'cancelled') {
            $cancellation_reason = null;
        }
        
        $stmt = $database->prepare("UPDATE appointment SET status = ?, rescheduled_date = ?, rescheduled_time = ?, cancellation_reason = ? WHERE appoid = ?");
        
        if ($stmt) {
            $stmt->bind_param("ssssi", $status, $rescheduled_date, $rescheduled_time, $cancellation_reason, $appoid);
            
            if($stmt->execute()){
                $_SESSION['success'] = "Appointment status updated successfully!";
            } else {
                $_SESSION['error'] = "Error updating appointment status: " . $database->error;
            }
            $stmt->close();
        } else {
            $_SESSION['error'] = "Error preparing statement: " . $database->error;
        }
        
        header("Location: appointment.php");
        exit();
    }
    

    $doctor_picture = "../img/user.png";
    $possible_picture_columns = ['docpicture', 'picture', 'profile_picture', 'doc_profile_picture'];

    foreach ($possible_picture_columns as $column) {
        if(isset($userfetch[$column]) && !empty($userfetch[$column])) {
            $picture_path = "../" . $userfetch[$column];
            if (file_exists($picture_path)) {
                $doctor_picture = $picture_path;
            }
            break;
        }
    }
    ?>
    <div class="container">
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="<?php echo $doctor_picture; ?>" alt="Profile Picture" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title"><?php echo substr($username,0,13); ?>..</p>
                                    <p class="profile-subtitle"><?php echo substr($useremail,0,22); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-dashbord" >
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment menu-active menu-icon-appoinment-active">
                        <a href="appointment.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">My Appointments</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">My Sessions</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-patient">
                        <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">My Patients</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a>
                    </td>
                </tr>
            </table>
        </div>
        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
                <tr >
                    <td width="13%" >
                    <a href="appointment.php" ><button  class="login-btn btn-primary-soft btn btn-icon-back"  style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                    </td>
                    <td>
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;">Appointment Manager</p>
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 
                                date_default_timezone_set('Asia/Kuala_Lumpur');
                                $today = date('Y-m-d');
                                echo $today;

                                $list110 = $database->query("select * from schedule inner join appointment on schedule.scheduleid=appointment.scheduleid inner join patient on patient.pid=appointment.pid inner join doctor on schedule.docid=doctor.docid  where  doctor.docid=$userid ");
                            ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button  class="btn-label"  style="display: flex;justify-content: center;align-items: center;"><img src="../img/calendar.svg" width="100%"></button>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="4" style="padding-top:10px;width: 100%;" >
                        <p class="heading-main12" style="margin-left: 45px;font-size:18px;color:rgb(49, 49, 49)">My Appointments (<?php echo $list110->num_rows; ?>)</p>
                    </td>
                </tr>
                

                <tr>
                    <td colspan="4" style="padding-top:0px;width: 100%;" >
                        <center>
                            <table class="filter-container" border="0" >
                                <tr>
                                    <td width="10%"></td> 
                                    <td width="5%" style="text-align: center;">
                                        Date:
                                    </td>
                                    <td width="20%">
                                        <form action="" method="post">
                                            <input type="date" name="sheduledate" id="date" class="input-text filter-container-items" style="margin: 0;width: 95%;">
                                    </td>
                                    <td width="5%" style="text-align: center;">
                                        Status:
                                    </td>
                                    <td width="20%">
                                        <select name="status_filter" class="input-text filter-container-items" style="margin: 0;width: 95%;">
                                            <option value="">All Status</option>
                                            <option value="scheduled" <?php echo (isset($_POST['status_filter']) && $_POST['status_filter'] == 'scheduled') ? 'selected' : ''; ?>>Scheduled</option>
                                            <option value="completed" <?php echo (isset($_POST['status_filter']) && $_POST['status_filter'] == 'completed') ? 'selected' : ''; ?>>Completed</option>
                                            <option value="cancelled" <?php echo (isset($_POST['status_filter']) && $_POST['status_filter'] == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                            <option value="rescheduled" <?php echo (isset($_POST['status_filter']) && $_POST['status_filter'] == 'rescheduled') ? 'selected' : ''; ?>>Rescheduled</option>
                                        </select>
                                    </td>
                                    <td width="12%">
                                        <input type="submit" name="filter" value="Filter" class="btn-primary-soft btn button-icon btn-filter" style="padding: 15px; margin:0;width:100%">
                                        </form>
                                    </td>
                                </tr>
                            </table>
                        </center>
                    </td>
                </tr>
                
                <?php

                if(isset($_SESSION['success'])) {
                    echo '<tr><td colspan="4"><div class="success-message" style="color: green; background: #d4edda; padding: 10px; margin: 10px 45px; border-radius: 5px;">'.$_SESSION['success'].'</div></td></tr>';
                    unset($_SESSION['success']);
                }
                if(isset($_SESSION['error'])) {
                    echo '<tr><td colspan="4"><div class="error-message" style="color: red; background: #f8d7da; padding: 10px; margin: 10px 45px; border-radius: 5px;">'.$_SESSION['error'].'</div></td></tr>';
                    unset($_SESSION['error']);
                }

                $sqlmain= "select appointment.appoid, appointment.status, appointment.rescheduled_date, appointment.rescheduled_time, appointment.cancellation_reason, schedule.scheduleid, schedule.title, schedule.nop, doctor.docname, patient.pname, patient.pid, schedule.scheduledate, schedule.scheduletime, appointment.apponum, appointment.appodate from schedule inner join appointment on schedule.scheduleid=appointment.scheduleid inner join patient on patient.pid=appointment.pid inner join doctor on schedule.docid=doctor.docid  where  doctor.docid=$userid ";

                if($_POST){
                    if(!empty($_POST["sheduledate"])){
                        $sheduledate=$_POST["sheduledate"];
                        $sqlmain.=" and schedule.scheduledate='$sheduledate' ";
                    }
                    if(!empty($_POST["status_filter"])){
                        $status_filter=$_POST["status_filter"];
                        $sqlmain.=" and appointment.status='$status_filter' ";
                    }
                }
                ?>
                  
                <tr>
                   <td colspan="4">
                       <center>
                        <div class="abc scroll">
                        <table width="93%" class="sub-table scrolldown" border="0">
                        <thead>
                        <tr>
                                <th class="table-headin">Patient Name</th>
                                <th class="table-headin">Appointment No.</th>
                                <th class="table-headin">Session Title</th>
                                <th class="table-headin">Session Date & Time</th>
                                <th class="table-headin">Status</th>
                                <th class="table-headin">Events</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $result= $database->query($sqlmain);

                                if($result->num_rows==0){
                                    echo '<tr>
                                    <td colspan="7">
                                    <br><br><br><br>
                                    <center>
                                    <img src="../img/notfound.svg" width="25%">
                                    <br>
                                    <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">We couldn\'t find anything related to your keywords!</p>
                                    <a class="non-style-link" href="appointment.php"><button  class="login-btn btn-primary-soft btn"  style="display: flex;justify-content: center;align-items: center;margin-left:20px;">&nbsp; Show all Appointments &nbsp;</button></a>
                                    </center>
                                    <br><br><br><br>
                                    </td>
                                    </tr>';
                                } else {
                                    for ($x=0; $x<$result->num_rows;$x++){
                                        $row=$result->fetch_assoc();
                                        $appoid=$row["appoid"];
                                        $scheduleid=$row["scheduleid"];
                                        $title=$row["title"];
                                        $nop=$row["nop"];
                                        $docname=$row["docname"];
                                        $sheduledate=$row["scheduledate"];
                                        $scheduletime=$row["scheduletime"];
                                        $pname=$row["pname"];
                                        $pid=$row["pid"];
                                        $apponum=$row["apponum"];
                                        $appodate=$row["appodate"];
                                        $status=$row["status"];
                                        $rescheduled_date=$row["rescheduled_date"];
                                        $rescheduled_time=$row["rescheduled_time"];
                                        $cancellation_reason=$row["cancellation_reason"];
                                        

                                        $bookings_query = $database->query("SELECT COUNT(*) as booked_count FROM appointment WHERE scheduleid=$scheduleid AND status != 'cancelled'");
                                        $bookings_data = $bookings_query->fetch_assoc();
                                        $booked_count = $bookings_data['booked_count'];
                                        

                                        $status_badge = '';
                                        switch($status) {
                                            case 'scheduled':
                                                $status_badge = '<span class="status-badge status-scheduled">Scheduled</span>';
                                                break;
                                            case 'completed':
                                                $status_badge = '<span class="status-badge status-completed">Completed</span>';
                                                break;
                                            case 'cancelled':
                                                $status_badge = '<span class="status-badge status-cancelled">Cancelled</span>';
                                                break;
                                            case 'rescheduled':
                                                $status_badge = '<span class="status-badge status-rescheduled">Rescheduled</span>';
                                                break;
                                            default:
                                                $status_badge = '<span class="status-badge status-scheduled">Scheduled</span>';
                                        }
                                        

                                        $session_title = substr($title,0,15);
                                        $capacity_class = '';
                                        if ($booked_count >= $nop) {
                                            $capacity_class = 'capacity-full';
                                        } elseif ($booked_count >= ($nop * 0.8)) {
                                            $capacity_class = 'capacity-warning';
                                        }
                                        
                                        echo '<tr>
                                            <td style="font-weight:600;"> &nbsp;'.substr($pname,0,25).'</td>
                                            <td style="text-align:center;font-size:23px;font-weight:500; color: var(--btnnicetext);">
                                            '.$apponum.'
                                            </td>
                                            <td>
                                                '.$session_title.'
                                                <div class="capacity-info '.$capacity_class.'">
                                                    '.$booked_count.'/'.$nop.' booked
                                                </div>
                                            </td>
                                            <td style="text-align:center;">';
                                            
                                        if($status == 'rescheduled' && $rescheduled_date) {
                                            echo '<div>Original: '.substr($sheduledate,0,10).' @'.substr($scheduletime,0,5).'</div>';
                                            echo '<div style="color: #ef6c00; font-weight: bold;">New: '.substr($rescheduled_date,0,10).' @'.substr($rescheduled_time,0,5).'</div>';
                                        } else {
                                            echo substr($sheduledate,0,10).' @'.substr($scheduletime,0,5);
                                        }
                                        
                                        echo '</td>
                                            <td style="text-align:center;">'.$status_badge.'</td>
                                            <td>
                                                <div style="display: flex; gap: 5px; justify-content: center;">
                                                    <a href="?action=view&id='.$appoid.'" class="non-style-link">
                                                        <button class="btn-primary-soft btn">&nbsp;View&nbsp;</button>
                                                    </a>
                                                    <a href="prescription-create.php?patient_id='.$pid.'&appointment_id='.$appoid.'" class="non-style-link">
                                                        <button class="btn-primary-soft btn" style="background: #28a745; border-color: #28a745;">&nbsp;Prescribe&nbsp;</button>
                                                    </a>
                                                    <a href="?action=update_status&id='.$appoid.'" class="non-style-link">
                                                        <button class="btn-primary-soft btn" style="background: #ff9800; border-color: #ff9800;">&nbsp;Status&nbsp;</button>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>';
                                    }
                                }
                            ?>
                            </tbody>
                        </table>
                        </div>
                        </center>
                   </td> 
                </tr>
            </table>
        </div>
    </div>


    <?php
    if($_GET && $_GET['action']=='update_status'){
        $id=$_GET["id"];
        $sqlmain= "select appointment.*, patient.pname, schedule.scheduledate, schedule.scheduletime, schedule.nop from appointment inner join patient on appointment.pid=patient.pid inner join schedule on appointment.scheduleid=schedule.scheduleid where appointment.appoid='$id'";
        $result= $database->query($sqlmain);
        $row=$result->fetch_assoc();
        
        $pname=$row["pname"];
        $current_status=$row["status"] ?: 'scheduled';
        $scheduledate=$row["scheduledate"];
        $scheduletime=$row["scheduletime"];
        $nop=$row["nop"];
        $rescheduled_date=$row["rescheduled_date"];
        $rescheduled_time=$row["rescheduled_time"];
        $cancellation_reason=$row["cancellation_reason"];
        

        $scheduleid = $row["scheduleid"];
        $capacity_query = $database->query("SELECT COUNT(*) as booked_count FROM appointment WHERE scheduleid=$scheduleid AND status != 'cancelled'");
        $capacity_data = $capacity_query->fetch_assoc();
        $booked_count = $capacity_data['booked_count'];
        
        echo '
        <div id="popup1" class="overlay">
            <div class="popup">
            <center>
                <a class="close" href="appointment.php">&times;</a>
                <div style="display: flex;justify-content: center;">
                <div class="abc">
                <table width="80%" class="sub-table scrolldown add-doc-form-container" border="0">
                <tr>
                    <td colspan="2">
                        <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">Update Appointment Status</p><br>
                        <p><strong>Patient:</strong> '.$pname.'</p>
                        <p><strong>Original Date:</strong> '.$scheduledate.' '.$scheduletime.'</p>
                        <p><strong>Session Capacity:</strong> '.$booked_count.'/'.$nop.' patients booked</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                    <form action="" method="POST" class="add-new-form">
                        <input type="hidden" name="appoid" value="'.$id.'">
                        <input type="hidden" name="update_status" value="1">
                        
                        <div class="form-group">
                            <label for="status" class="form-label">Status:</label>
                            <select name="status" id="status" class="input-text" required onchange="toggleStatusFields()">
                                <option value="scheduled" '.($current_status=='scheduled'?'selected':'').'>Scheduled</option>
                                <option value="completed" '.($current_status=='completed'?'selected':'').'>Completed</option>
                                <option value="cancelled" '.($current_status=='cancelled'?'selected':'').'>Cancelled</option>
                                <option value="rescheduled" '.($current_status=='rescheduled'?'selected':'').'>Rescheduled</option>
                            </select>
                        </div>
                        
                        <div id="reschedule-fields" style="display: '.($current_status=='rescheduled'?'block':'none').';">
                            <div class="form-group">
                                <label for="rescheduled_date" class="form-label">New Date:</label>
                                <input type="date" name="rescheduled_date" class="input-text" value="'.$rescheduled_date.'" min="'.date('Y-m-d').'">
                            </div>
                            <div class="form-group">
                                <label for="rescheduled_time" class="form-label">New Time:</label>
                                <input type="time" name="rescheduled_time" class="input-text" value="'.$rescheduled_time.'">
                            </div>
                        </div>
                        
                        <div id="cancel-fields" style="display: '.($current_status=='cancelled'?'block':'none').';">
                            <div class="form-group">
                                <label for="cancellation_reason" class="form-label">Cancellation Reason:</label>
                                <textarea name="cancellation_reason" class="input-text" placeholder="Optional reason for cancellation" rows="3">'.$cancellation_reason.'</textarea>
                            </div>
                        </div>
                        
                        <div style="margin-top: 20px;">
                            <input type="submit" value="Update Status" class="login-btn btn-primary btn">
                            <a href="appointment.php" class="non-style-link"><input type="button" value="Cancel" class="login-btn btn-primary-soft btn" style="margin-left: 10px;"></a>
                        </div>
                    </form>
                    </td>
                </tr>
                </table>
                </div>
                </div>
            </center>
            </div>
        </div>
        
        <script>
        function toggleStatusFields() {
            var status = document.getElementById("status").value;
            document.getElementById("reschedule-fields").style.display = (status == "rescheduled") ? "block" : "none";
            document.getElementById("cancel-fields").style.display = (status == "cancelled") ? "block" : "none";
        }
        </script>
        ';
    }
    ?>


    <?php
    if($_GET && $_GET['action']=='view'){
        $id=$_GET["id"];
        $sqlmain= "select appointment.*, patient.pname, patient.pemail, patient.pnic, patient.ptel, schedule.title, schedule.scheduledate, schedule.scheduletime, schedule.nop from appointment inner join patient on appointment.pid=patient.pid inner join schedule on appointment.scheduleid=schedule.scheduleid where appointment.appoid='$id'";
        $result= $database->query($sqlmain);
        $row=$result->fetch_assoc();
        
        $pname=$row["pname"];
        $pemail=$row["pemail"];
        $pnic=$row["pnic"];
        $ptel=$row["ptel"];
        $title=$row["title"];
        $scheduledate=$row["scheduledate"];
        $scheduletime=$row["scheduletime"];
        $nop=$row["nop"];
        $apponum=$row["apponum"];
        $appodate=$row["appodate"];
        $status=$row["status"];
        $rescheduled_date=$row["rescheduled_date"];
        $rescheduled_time=$row["rescheduled_time"];
        $cancellation_reason=$row["cancellation_reason"];
        

        $scheduleid = $row["scheduleid"];
        $capacity_query = $database->query("SELECT COUNT(*) as booked_count FROM appointment WHERE scheduleid=$scheduleid AND status != 'cancelled'");
        $capacity_data = $capacity_query->fetch_assoc();
        $booked_count = $capacity_data['booked_count'];
        
        echo '
        <div id="popup1" class="overlay">
            <div class="popup">
            <center>
                <h2>Appointment Details</h2>
                <a class="close" href="appointment.php">&times;</a>
                <div class="content">
                    Detailed appointment information<br>
                </div>
                <div style="display: flex;justify-content: center;">
                <table width="80%" class="sub-table scrolldown add-doc-form-container" border="0">
                    <tr>
                        <td>
                            <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">Appointment Details</p><br><br>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                            <label for="name" class="form-label">Patient Name: </label>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                            '.$pname.'<br><br>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                            <label for="Email" class="form-label">Email: </label>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                        '.$pemail.'<br><br>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                            <label for="nic" class="form-label">NIC: </label>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                        '.$pnic.'<br><br>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                            <label for="Tele" class="form-label">Phone Number: </label>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                        '.$ptel.'<br><br>
                        </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                            <label for="spec" class="form-label">Session Title: </label>
                        </td>
                    </tr>
                    <tr>
                    <td class="label-td" colspan="2">
                    '.$title.'<br><br>
                    </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                            <label for="spec" class="form-label">Session Capacity: </label>
                        </td>
                    </tr>
                    <tr>
                    <td class="label-td" colspan="2">
                    '.$booked_count.'/'.$nop.' patients booked<br><br>
                    </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                            <label for="spec" class="form-label">Appointment Number: </label>
                        </td>
                    </tr>
                    <tr>
                    <td class="label-td" colspan="2">
                    '.$apponum.'<br><br>
                    </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                            <label for="spec" class="form-label">Appointment Date: </label>
                        </td>
                    </tr>
                    <tr>
                    <td class="label-td" colspan="2">
                    '.$appodate.'<br><br>
                    </td>
                    </tr>
                    <tr>
                        <td class="label-td" colspan="2">
                            <label for="spec" class="form-label">Scheduled Date & Time: </label>
                        </td>
                    </tr>
                    <tr>
                    <td class="label-td" colspan="2">
                    '.$scheduledate.' '.$scheduletime.'<br><br>
                    </td>
                    </tr>';
        
        if($status == 'rescheduled' && $rescheduled_date) {
            echo '<tr>
                    <td class="label-td" colspan="2">
                        <label for="spec" class="form-label">Rescheduled Date & Time: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2" style="color: #ef6c00; font-weight: bold;">
                    '.$rescheduled_date.' '.$rescheduled_time.'<br><br>
                    </td>
                </tr>';
        }
        
        if($status == 'cancelled' && $cancellation_reason) {
            echo '<tr>
                    <td class="label-td" colspan="2">
                        <label for="spec" class="form-label">Cancellation Reason: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    '.$cancellation_reason.'<br><br>
                    </td>
                </tr>';
        }
        
        echo '<tr>
                    <td class="label-td" colspan="2">
                        <label for="spec" class="form-label">Status: </label>
                    </td>
                </tr>
                <tr>
                <td class="label-td" colspan="2">';
        
        switch($status) {
            case 'scheduled':
                echo '<span class="status-badge status-scheduled">Scheduled</span>';
                break;
            case 'completed':
                echo '<span class="status-badge status-completed">Completed</span>';
                break;
            case 'cancelled':
                echo '<span class="status-badge status-cancelled">Cancelled</span>';
                break;
            case 'rescheduled':
                echo '<span class="status-badge status-rescheduled">Rescheduled</span>';
                break;
            default:
                echo '<span class="status-badge status-scheduled">Scheduled</span>';
        }
        
        echo '<br><br>
                </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <a href="appointment.php"><input type="button" value="OK" class="login-btn btn-primary-soft btn" ></a>
                    </td>
                </tr>
            </table>
            </div>
        </center>
        <br><br>
    </div>
    </div>
    ';  
}
?>
</body>
</html>