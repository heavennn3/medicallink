<?php
session_start();
include("../connection.php");

if(isset($_SESSION["user"]) && $_SESSION['usertype']=='d') {
    $useremail = $_SESSION["user"];
    
    // Get doctor ID
    $sqlmain = "SELECT docid FROM doctor WHERE docemail=?";
    $stmt = $database->prepare($sqlmain);
    $stmt->bind_param("s", $useremail);
    $stmt->execute();
    $result = $stmt->get_result();
    $userfetch = $result->fetch_assoc();
    $userid = $userfetch["docid"];
    
    if(isset($_FILES['doctor-picture']) && $_FILES['doctor-picture']['error'] == 0) {
        $target_dir = "../img/doctors/";
        
        // Create directory if it doesn't exist
        if(!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        // Generate unique filename
        $file_extension = strtolower(pathinfo($_FILES["doctor-picture"]["name"], PATHINFO_EXTENSION));
        $allowed_extensions = array("jpg", "jpeg", "png", "gif");
        
        // Check if file is an image
        $check = getimagesize($_FILES["doctor-picture"]["tmp_name"]);
        if($check === false) {
            header("location: settings.php?upload=notimage");
            exit();
        }
        
        // Check file extension
        if(!in_array($file_extension, $allowed_extensions)) {
            header("location: settings.php?upload=invalidformat");
            exit();
        }
        
        // Check file size (max 5MB)
        if($_FILES["doctor-picture"]["size"] > 5000000) {
            header("location: settings.php?upload=filetoolarge");
            exit();
        }
        
        // Generate unique filename
        $new_filename = "doctor_" . $userid . "_" . time() . "." . $file_extension;
        $target_file = $target_dir . $new_filename;
        
        // Move uploaded file
        if(move_uploaded_file($_FILES["doctor-picture"]["tmp_name"], $target_file)) {
            // Update database with new picture path
            $picture_path = "img/doctors/" . $new_filename;
            $sql = "UPDATE doctor SET docpicture = ? WHERE docid = ?";
            $stmt = $database->prepare($sql);
            $stmt->bind_param("si", $picture_path, $userid);
            
            if($stmt->execute()) {
                header("location: settings.php?upload=success");
            } else {
                header("location: settings.php?upload=dberror");
            }
        } else {
            header("location: settings.php?upload=error");
        }
    } else {
        header("location: settings.php?upload=noimage");
    }
} else {
    header("location: ../login.php");
}
?>