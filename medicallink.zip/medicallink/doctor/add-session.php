<?php
    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='d'){
            header("location: ../login.php");
        }else{
            $useremail=$_SESSION["user"];
        }
    }else{
        header("location: ../login.php");
    }
    
    if($_POST){
        include("../connection.php");
        
        $sqlmain= "select * from doctor where docemail=?";
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("s",$useremail);
        $stmt->execute();
        $userrow = $stmt->get_result();
        $userfetch=$userrow->fetch_assoc();
        $userid= $userfetch["docid"];
        
        $title=$_POST["title"];
        $nop=$_POST["nop"];
        $date=$_POST["date"];
        $time=$_POST["time"];
        
     
        if($nop <= 0) {
            header("location: schedule.php?action=add-session&id=none&error=1");
            exit;
        }
        
        if($nop > 50) {
            header("location: schedule.php?action=add-session&id=none&error=4");
            exit;
        }
        

        if($date < date('Y-m-d')) {
            header("location: schedule.php?action=add-session&id=none&error=2");
            exit;
        }
        

        $check_conflict_sql = "SELECT * FROM schedule WHERE docid=? AND scheduledate=? AND scheduletime=?";
        $check_stmt = $database->prepare($check_conflict_sql);
        $check_stmt->bind_param("iss", $userid, $date, $time);
        $check_stmt->execute();
        $conflict_result = $check_stmt->get_result();

        if($conflict_result->num_rows > 0) {
            header("location: schedule.php?action=add-session&id=none&error=3");
            exit;
        }
        

        $check_day_sessions_sql = "SELECT COUNT(*) as day_sessions FROM schedule WHERE docid=? AND scheduledate=?";
        $day_stmt = $database->prepare($check_day_sessions_sql);
        $day_stmt->bind_param("is", $userid, $date);
        $day_stmt->execute();
        $day_result = $day_stmt->get_result();
        $day_data = $day_result->fetch_assoc();
        

        if($day_data['day_sessions'] >= 8) {
            header("location: schedule.php?action=add-session&id=none&error=5");
            exit;
        }
        
        $sql="insert into schedule (docid,title,scheduledate,scheduletime,nop) values (?,?,?,?,?)";
        $stmt = $database->prepare($sql);
        $stmt->bind_param("isssi", $userid, $title, $date, $time, $nop);
        
        if($stmt->execute()){
            header("location: schedule.php?action=session-added&title=$title");
        } else {
            header("location: schedule.php?action=add-session&id=none&error=6");
        }
        
    }
?>