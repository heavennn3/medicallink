<?php
// Enhanced email configuration for Medical Link

// Use statements must be at the top of the file
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files
require_once 'PHPMailer/src/PHPMailer.php';
require_once 'PHPMailer/src/SMTP.php';
require_once 'PHPMailer/src/Exception.php';

function sendReceiptEmailEnhanced($appointment, $to_email, $cc_email = null) {    
    $mail = new PHPMailer(true);
    
    try {
        // Server settings - GMAIL SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = '2024933969@student.uitm.edu.my';
        $mail->Password = 'ueazxzghlyaltjkm';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        // Recipients
        $mail->setFrom('noreply@medicallink.com', 'Medical Link System');
        $mail->addAddress($to_email);
        
        if($cc_email) {
            $mail->addCC($cc_email);
        }
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = "Medical Appointment Receipt - Reference OC-000-" . $appointment['appoid'];
        $mail->Body = generateReceiptHTML($appointment);
        $mail->AltBody = generateReceiptText($appointment);
        
        // Send email
        if($mail->send()) {
            error_log("Email sent successfully to: " . $to_email);
            return true;
        } else {
            error_log("Email failed to send to: " . $to_email);
            return false;
        }
        
    } catch (Exception $e) {
        error_log("Email sending failed: " . $mail->ErrorInfo);
        return false;
    }
}

function generateReceiptText($appointment) {
    $receipt_number = "OC-000-" . $appointment['appoid'];
    
    return "
MEDICAL LINK - APPOINTMENT RECEIPT
==================================

Receipt Number: $receipt_number
Booking Date: " . date('F j, Y', strtotime($appointment['appodate'])) . "
Patient Name: " . $appointment['pname'] . "
Doctor: Dr. " . $appointment['docname'] . "
Session: " . $appointment['title'] . "
Appointment Date: " . date('F j, Y', strtotime($appointment['scheduledate'])) . "
Appointment Time: " . date('g:i A', strtotime($appointment['scheduletime'])) . "
Appointment Number: " . $appointment['apponum'] . "

Consultation Fee: RM 150.00

Thank you for choosing Medical Link!
Contact: +603-1234 5678 | Email: info@medicallink.com
";
}

function generateReceiptHTML($appointment) {
    $receipt_number = "OC-000-" . $appointment['appoid'];
    
    return "
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #4CAF50; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background: #f9f9f9; }
        .footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
        .receipt-details { background: white; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .receipt-number { font-size: 18px; font-weight: bold; color: #4CAF50; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h1>MEDICAL LINK</h1>
            <h2>APPOINTMENT RECEIPT</h2>
        </div>
        
        <div class='content'>
            <div class='receipt-details'>
                <p class='receipt-number'>Receipt Number: $receipt_number</p>
                <p><strong>Booking Date:</strong> " . date('F j, Y', strtotime($appointment['appodate'])) . "</p>
                <p><strong>Patient Name:</strong> " . $appointment['pname'] . "</p>
                <p><strong>Doctor:</strong> Dr. " . $appointment['docname'] . "</p>
                <p><strong>Session:</strong> " . $appointment['title'] . "</p>
                <p><strong>Appointment Date:</strong> " . date('F j, Y', strtotime($appointment['scheduledate'])) . "</p>
                <p><strong>Appointment Time:</strong> " . date('g:i A', strtotime($appointment['scheduletime'])) . "</p>
                <p><strong>Appointment Number:</strong> " . $appointment['apponum'] . "</p>
                <hr>
                <p><strong>Consultation Fee:</strong> RM 150.00</p>
            </div>
        </div>
        
        <div class='footer'>
            <p>Thank you for choosing Medical Link!</p>
            <p>Contact: +603-1234 5678 | Email: info@medicallink.com</p>
            <p>This is an automated email, please do not reply.</p>
        </div>
    </div>
</body>
</html>
";
}

// Additional email function for general purposes
function sendMedicalEmail($to, $subject, $message, $isHTML = true) {
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = '2024933969@student.uitm.edu.my';
        $mail->Password = 'ueazxzghlyaltjkm';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        $mail->setFrom('noreply@medicallink.com', 'Medical Link');
        $mail->addAddress($to);
        
        $mail->isHTML($isHTML);
        $mail->Subject = $subject;
        $mail->Body = $message;
        
        if(!$isHTML) {
            $mail->AltBody = $message;
        }
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("General email failed: " . $mail->ErrorInfo);
        return false;
    }
}
?>