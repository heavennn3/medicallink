<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/modal.css">

    <title>Login</title>

</head>
<body>
    <?php

    session_start();

    $_SESSION["user"]="";
    $_SESSION["usertype"]="";

    date_default_timezone_set('Asia/Kuala_Lumpur');
    $date = date('Y-m-d');

    $_SESSION["date"]=$date;

    include("connection.php");

    // Forgot Password Handling
    if(isset($_POST['forgot_password'])) {
        $email = $_POST['useremail'];
        
        $result = $database->query("SELECT * FROM webuser WHERE email='$email'");
        if($result->num_rows == 1) {
            // Generate reset token (simple version - in production use more secure method)
            $reset_token = bin2hex(random_bytes(16));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Store token in database (you'll need to add a reset_token and reset_expiry column to webuser table)
            $database->query("UPDATE webuser SET reset_token='$reset_token', reset_expiry='$expiry' WHERE email='$email'");
            
            // In a real application, you would send an email here
            // For now, we'll just show a message with the reset link
            $reset_link = "reset-password.php?token=$reset_token&email=" . urlencode($email);
            $forgot_success = '<label for="promter" class="form-label" style="color:green;text-align:center;">Password reset link has been generated. <a href="' . $reset_link . '">Click here to reset password</a></label>';
        } else {
            $forgot_error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Email not found in our system.</label>';
        }
    }

    // Regular Login Handling
    if($_POST && !isset($_POST['forgot_password'])){

        $email=$_POST['useremail'];
        $password=$_POST['userpassword'];

        $error='<label for="promter" class="form-label"></label>';

        $result= $database->query("select * from webuser where email='$email'");
        if($result->num_rows==1){
            $utype=$result->fetch_assoc()['usertype'];
            if ($utype=='p'){

                $checker = $database->query("select * from patient where pemail='$email' and ppassword='$password'");
                if ($checker->num_rows==1){

                    $_SESSION['user']=$email;
                    $_SESSION['usertype']='p';

                    header('location: patient/index.php');

                }else{
                    $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';
                }

            }elseif($utype=='a'){

                $checker = $database->query("select * from admin where aemail='$email' and apassword='$password'");
                if ($checker->num_rows==1){

                    $_SESSION['user']=$email;
                    $_SESSION['usertype']='a';

                    header('location: admin/index.php');

                }else{
                    $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';
                }

            }elseif($utype=='d'){

                $checker = $database->query("select * from doctor where docemail='$email' and docpassword='$password'");
                if ($checker->num_rows==1){

                    $_SESSION['user']=$email;
                    $_SESSION['usertype']='d';
                    header('location: doctor/index.php');

                }else{
                    $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';
                }

            }

        }else{
            $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">We cant found any acount for this email.</label>';
        }

    }else{
        $error='<label for="promter" class="form-label">&nbsp;</label>';
    }
    ?>

    <center>
    <div class="container">
        <table border="0" style="margin: 0;padding: 0;width: 60%;">
            <tr>
                <td>
                    <p class="header-text">Welcome Back!</p>
                </td>
            </tr>
        <div class="form-body">
            <tr>
                <td>
                    <p class="sub-text">Login with your details to continue</p>
                </td>
            </tr>
            <tr>
                <form action="" method="POST" >
                <td class="label-td">
                    <label for="useremail" class="form-label">Email: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <input type="email" name="useremail" class="input-text" placeholder="Email Address" required>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <label for="userpassword" class="form-label">Password: </label>
                </td>
            </tr>

            <tr>
                <td class="label-td">
                    <input type="Password" name="userpassword" class="input-text" placeholder="Password" required>
                </td>
            </tr>

            <tr>
                <td><br>
                <?php echo $error ?>
                </td>
            </tr>

            <tr>
                <td>
                    <input type="submit" value="Login" class="login-btn btn-primary btn">
                </td>
            </tr>
        </div>
            <tr>
                <td>
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">Don't have an account&#63; </label>
                    <a href="signup.php" class="hover-link1 non-style-link">Sign Up</a>
                    <br>
                    
                    <!-- Forgot Password Link -->
                    <label for="" class="sub-text" style="font-weight: 280;">Forgot your password&#63; </label>
                    <a href="javascript:void(0);" onclick="showForgotPassword()" class="hover-link1 non-style-link">Reset Password</a>
                    <br><br><br>
                </td>
            </tr>

                    </form>
        </table>
    </div>
</center>

<!-- Forgot Password Modal -->
<div id="forgotPasswordModal" class="modal">
    <div class="modal-content">
        <button class="close-btn" onclick="hideForgotPassword()">&times;</button>
        <div class="modal-header">
            <p class="header-text">Reset Your Password</p>
            <p class="sub-text">Enter your email to receive a password reset link</p>
        </div>
        <form action="" method="POST">
            <div class="label-td">
                <label for="forgot_email" class="form-label">Email: </label>
            </div>
            <div class="label-td">
                <input type="email" name="useremail" class="input-text" placeholder="Email Address" required>
            </div>
            <div class="message-container">
                <?php 
                if(isset($forgot_success)) echo $forgot_success;
                if(isset($forgot_error)) echo $forgot_error;
                ?>
            </div>
            <div class="modal-footer">
                <input type="submit" name="forgot_password" value="Send Reset Link" class="login-btn btn-primary btn">
                <button type="button" onclick="hideForgotPassword()" class="btn-secondary">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
    function showForgotPassword() {
        document.getElementById('forgotPasswordModal').style.display = 'flex';
    }
    
    function hideForgotPassword() {
        document.getElementById('forgotPasswordModal').style.display = 'none';
        // Clear any messages when closing
        document.querySelector('.message-container').innerHTML = '';
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
        const modal = document.getElementById('forgotPasswordModal');
        if (event.target === modal) {
            hideForgotPassword();
        }
    }
</script>
</body>
</html>